
export type User = {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'teacher' | 'student' | 'parent';
};

export type Student = {
  id: string;
  name: string;
  enrollmentNumber: string;
  dateOfBirth: string;
  gender: string;
  classId: string;
  className: string;
  parentName: string;
  parentContact: string;
  address: string;
  joinDate: string;
  fees: {
    paid: number;
    due: number;
    lastPaymentDate: string | null;
  };
  payments?: PaymentRecord[];
  profileImage?: string;
  email?: string;
  bloodGroup?: string;
  emergencyContact?: string;
  medicalConditions?: string;
  boardingStatus?: 'Boarding' | 'Day';
  transportUse?: 'Yes' | 'No';
  bestColor?: string;
  clubsActivities?: string[];
};

export type PaymentRecord = {
  id: string;
  date: string;
  amount: number;
  method: 'Cash' | 'Bank Transfer' | 'Mobile Money' | 'Card' | 'Other';
  receiptNo: string;
  description?: string;
  notes?: string;
  createdAt: string;
  createdBy?: string;
  updatedAt?: string;
  updatedBy?: string;
};

export interface Teacher {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  subjects?: string[];
  classTeacherFor?: string;
  joinDate?: string;
  qualification?: string;
  specialization?: string;
  biography?: string;
  gender?: string;
  dateOfBirth?: string;
  employeeId?: string;
  salary?: number;
  hireDate?: string;
  address?: string;
  emergencyContact?: string;
  profileImage?: string;
  status?: string;
}

export type ClassInfo = {
  id: string;
  name: string;
  teacher: string;
  studentsCount: number;
  subjects: string[];
};

export type Subject = {
  id: string;
  name: string;
  teacherId: string;
  teacherName: string;
  classes: string[];
};

export type Timetable = {
  id: string;
  classId: string;
  className: string;
  daySchedule: {
    day: string;
    periods: TimetablePeriod[];
  }[];
};

export type TimetablePeriod = {
  id: string;
  startTime: string;
  endTime: string;
  subject: string;
  teacher: string;
};

export type Attendance = {
  id: string;
  date: string;
  classId: string;
  className: string;
  students: {
    id: string;
    name: string;
    present: boolean;
    remark: string;
  }[];
};

export type Exam = {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  classes: string[];
  status: 'upcoming' | 'ongoing' | 'completed';
};

export type Mark = {
  id: string;
  examId: string;
  examName: string;
  studentId: string;
  studentName: string;
  classId: string;
  className: string;
  subjects: {
    name: string;
    marksObtained: number;
    totalMarks: number;
    grade: string;
  }[];
  total: number;
  percentage: number;
  rank: number;
};

export type SchoolProperty = {
  id: string;
  name: string;
  category: string;
  quantity: number;
  condition: 'excellent' | 'good' | 'average' | 'poor';
  location: string;
  acquiredDate: string;
};

export type LibraryItem = {
  id: string;
  title: string;
  author: string;
  category: string;
  availableCopies: number;
  totalCopies: number;
  borrowedBy: {
    userId: string;
    userName: string;
    role: 'teacher' | 'student';
    borrowDate: string;
    dueDate: string;
  }[];
};

export type SyncStatus = {
  lastSyncedAt: string | null;
  syncedWithDevices: string[];
  pendingChanges: number;
  status: 'synced' | 'syncing' | 'offline' | 'error';
};
