
import { User } from '.';

export type Payment = {
  id: string;
  studentId: string;
  studentName?: string;
  amount: number;
  method: PaymentMethod;
  description: string;
  receivedBy: string;
  academicTerm: string;
  academicYear: string;
  createdAt: string;
  updatedAt?: string;
};

export type PaymentMethod = 'Cash' | 'Mobile Money' | 'Bank Transfer' | 'Card' | 'Other';

export type PaymentSummary = {
  total: number;
  paid: number;
  balance: number;
  lastPaymentDate: string | null;
};

export type PaymentStats = {
  daily: number;
  weekly: number;
  monthly: number;
  termly: number;
  yearly: number;
};
