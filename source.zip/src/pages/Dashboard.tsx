import React from 'react';
import { useQuery } from '@tanstack/react-query';
import MainLayout from '@/components/layout/MainLayout';
import EnhancedDashboardStats from '@/components/dashboard/EnhancedDashboardStats';
import AnimatedRevenueChart from '@/components/dashboard/AnimatedRevenueChart';
import AttendancePendingWidget from '@/components/dashboard/AttendancePendingWidget';
import PendingSalariesWidget from '@/components/dashboard/PendingSalariesWidget';
import AIInsightsWidget from '@/components/dashboard/AIInsightsWidget';
import OngoingSubjectsCard from '@/components/dashboard/OngoingSubjectsCard';
import UpcomingExams from '@/components/dashboard/UpcomingExams';
import DashboardSkeleton from '@/components/common/DashboardSkeleton';
import { supabase } from '@/integrations/supabase/client';

const Dashboard = () => {
  const { data: isLoading = true } = useQuery({
    queryKey: ['dashboard-ready'],
    queryFn: async () => {
      const { data } = await supabase.from('students').select('id').limit(1);
      return false;
    },
    retry: 1,
  });

  if (isLoading) {
    return <DashboardSkeleton />;
  }

  return (
    <MainLayout>
      <div className="space-y-4 md:space-y-6">
        {/* Header Section */}
        <div>
          <h1 className="text-xl md:text-2xl font-bold tracking-tight">
            Dashboard
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Overview of your school's performance
          </p>
        </div>

        {/* Compact Stats */}
        <EnhancedDashboardStats />
        
        {/* Main Content Grid - Compact for mobile */}
        <div className="grid gap-3 md:gap-4 grid-cols-1 lg:grid-cols-3">
          {/* Revenue Chart - Smaller on mobile */}
          <div className="lg:col-span-2 min-w-0">
            <AnimatedRevenueChart />
          </div>
          
          {/* AI Insights - Compact */}
          <div className="lg:col-span-1 min-w-0">
            <AIInsightsWidget />
          </div>
        </div>
        
        {/* Secondary Widgets */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <AttendancePendingWidget />
          <PendingSalariesWidget />
          <OngoingSubjectsCard />
          <UpcomingExams />
        </div>
      </div>
    </MainLayout>
  );
};

export default Dashboard;
