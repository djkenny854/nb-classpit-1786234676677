
import React from 'react';
import MainLayout from '@/components/layout/MainLayout';
import TeachersList from '@/components/teachers/TeachersList';

const Teachers = () => {
  return (
    <MainLayout>
      <TeachersList />
    </MainLayout>
  );
};

export default Teachers;
