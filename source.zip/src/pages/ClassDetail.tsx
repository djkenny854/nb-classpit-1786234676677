import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Users, 
  GraduationCap, 
  DollarSign, 
  Calendar, 
  Bus, 
  AlertTriangle,
  ArrowLeft,
  Plus,
  MessageCircle,
  Printer,
  UserPlus
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import ClassSeatingLayout from '@/components/classroom/ClassSeatingLayout';
import ClassFeeStats from '@/components/classroom/ClassFeeStats';
import ClassPerformanceChart from '@/components/classroom/ClassPerformanceChart';
import ClassDetailSkeleton from '@/components/classroom/ClassDetailSkeleton';
import ClassAIInsights from '@/components/classroom/ClassAIInsights';
import ClassQuickActions from '@/components/classroom/ClassQuickActions';
import ClassRecentActivities from '@/components/classroom/ClassRecentActivities';

interface ClassDetails {
  name: string;
  stream?: string;
  level: string;
  color?: string;
  teacher?: {
    id: string;
    name: string;
    profile_image_url?: string;
    phone?: string;
    email?: string;
  };
  students: Array<{
    id: string;
    full_name: string;
    student_id: string;
    gender?: string;
    profile_image_url?: string;
    boarding_status?: string;
    transport?: string;
    fee_status?: string;
  }>;
  notes?: string;
}

const ClassDetail = () => {
  const { id: className } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [classData, setClassData] = useState<ClassDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [feeStats, setFeeStats] = useState({
    totalExpected: 0,
    totalCollected: 0,
    averageBalance: 0,
    defaulters: []
  });

  const fetchClassData = async () => {
    if (!className) return;

    try {
      setLoading(true);
      
      // Decode the class name from URL
      const decodedClassName = decodeURIComponent(className);

      // Get students in the class
      const { data: students, error: studentsError } = await supabase
        .from('students')
        .select('*')
        .eq('class', decodedClassName);

      if (studentsError) throw studentsError;

      // Get class teacher
      const { data: teacher, error: teacherError } = await supabase
        .from('teachers')
        .select('*')
        .eq('class_teacher_for', decodedClassName)
        .single();

      if (teacherError && teacherError.code !== 'PGRST116') {
        console.error('Error fetching teacher:', teacherError);
      }

      // Get fee statistics
      const { data: feeData, error: feeError } = await supabase
        .from('student_fees')
        .select('total_assigned_fees, total_paid, balance, student_id')
        .in('student_id', students?.map(s => s.id) || []);

      if (feeError) {
        console.error('Error fetching fee data:', feeError);
      }

      // Calculate fee stats
      const totalExpected = feeData?.reduce((sum, fee) => sum + Number(fee.total_assigned_fees), 0) || 0;
      const totalCollected = feeData?.reduce((sum, fee) => sum + Number(fee.total_paid), 0) || 0;
      const averageBalance = feeData?.length ? 
        feeData.reduce((sum, fee) => sum + Number(fee.balance), 0) / feeData.length : 0;

      // Get top defaulters
      const defaulters = feeData
        ?.filter(fee => Number(fee.balance) > 0)
        .sort((a, b) => Number(b.balance) - Number(a.balance))
        .slice(0, 5)
        .map(fee => {
          const student = students?.find(s => s.id === fee.student_id);
          return {
            id: fee.student_id,
            name: student?.full_name || 'Unknown',
            balance: Number(fee.balance)
          };
        }) || [];

      setFeeStats({
        totalExpected,
        totalCollected,
        averageBalance,
        defaulters
      });

      setClassData({
        name: decodedClassName,
        level: decodedClassName.replace(/\s+/g, ''),
        students: students || [],
        teacher: teacher || undefined,
        color: getClassColor(decodedClassName)
      });

    } catch (error) {
      console.error('Error fetching class data:', error);
      toast({
        title: "Error",
        description: "Failed to load class data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getClassColor = (className: string) => {
    const colors = ['bg-blue-100 text-blue-800', 'bg-green-100 text-green-800', 'bg-purple-100 text-purple-800'];
    return colors[className.length % colors.length];
  };

  const getGenderStats = () => {
    const boys = classData?.students.filter(s => s.gender?.toLowerCase() === 'male').length || 0;
    const girls = classData?.students.filter(s => s.gender?.toLowerCase() === 'female').length || 0;
    return { boys, girls };
  };

  const getTransportStats = () => {
    return classData?.students.filter(s => s.transport === 'Yes').length || 0;
  };

  const getAttendanceRate = () => {
    // This would typically come from attendance records
    return Math.floor(Math.random() * 15) + 85; // Mock data for now
  };

  useEffect(() => {
    fetchClassData();
  }, [className]);

  if (loading) {
    return (
      <MainLayout>
        <ClassDetailSkeleton />
      </MainLayout>
    );
  }

  if (!classData) {
    return (
      <MainLayout>
        <div className="text-center py-8">
          <h2 className="text-2xl font-bold text-gray-600">Class not found</h2>
          <Button onClick={() => navigate('/classes')} className="mt-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Classes
          </Button>
        </div>
      </MainLayout>
    );
  }

  const { boys, girls } = getGenderStats();
  const transportUsers = getTransportStats();
  const attendanceRate = getAttendanceRate();

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="outline" onClick={() => navigate('/classes')}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-3xl font-bold">{classData.name}</h1>
              <p className="text-muted-foreground">Class Details & Management</p>
            </div>
          </div>
          
          {/* Quick Actions */}
          <div className="flex space-x-2">
            <Button variant="outline" size="sm">
              <UserPlus className="w-4 h-4 mr-2" />
              Add Student
            </Button>
            <Button variant="outline" size="sm">
              <MessageCircle className="w-4 h-4 mr-2" />
              Message Class
            </Button>
            <Button variant="outline" size="sm">
              <Printer className="w-4 h-4 mr-2" />
              Print Report
            </Button>
          </div>
        </div>

        {/* Class Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Class Profile */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="w-5 h-5" />
                Class Profile
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Badge className={classData.color}>{classData.name}</Badge>
                <p className="text-sm text-muted-foreground">Academic Level: {classData.level}</p>
              </div>
            </CardContent>
          </Card>

          {/* Students Count */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Students
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="text-2xl font-bold">{classData.students.length}</div>
                <div className="flex justify-between text-sm">
                  <span>Boys: {boys}</span>
                  <span>Girls: {girls}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Fee Summary */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5" />
                Fee Summary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="text-lg font-semibold">
                  ${feeStats.totalCollected.toLocaleString()}
                </div>
                <div className="text-sm text-muted-foreground">
                  of ${feeStats.totalExpected.toLocaleString()} expected
                </div>
                <div className="text-xs text-orange-600">
                  Avg Balance: ${feeStats.averageBalance.toFixed(2)}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Attendance */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Attendance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="text-2xl font-bold">{attendanceRate}%</div>
                <div className="text-sm text-muted-foreground">This month</div>
                <div className="flex items-center gap-2 text-xs">
                  <Bus className="w-3 h-3" />
                  {transportUsers} use transport
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* AI Insights */}
        <ClassAIInsights 
          className={classData.name}
          students={classData.students}
          feeStats={feeStats}
        />

        {/* Quick Actions Grid */}
        <ClassQuickActions 
          className={classData.name}
          studentCount={classData.students.length}
        />

        {/* Teacher Info & Recent Activities */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Teacher Info */}
          {classData.teacher && (
            <Card>
              <CardHeader>
                <CardTitle>Class Teacher</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4">
                  <Avatar className="w-16 h-16">
                    <AvatarImage src={classData.teacher.profile_image_url} />
                    <AvatarFallback>
                      {classData.teacher.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-semibold text-lg">{classData.teacher.name}</h3>
                    {classData.teacher.phone && (
                      <p className="text-sm text-muted-foreground">📞 {classData.teacher.phone}</p>
                    )}
                    {classData.teacher.email && (
                      <p className="text-sm text-muted-foreground">✉️ {classData.teacher.email}</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recent Activities */}
          <ClassRecentActivities className={classData.name} />
        </div>

        {/* Fee Defaulters */}
        {feeStats.defaulters.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-500" />
                Fee Defaulters
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {feeStats.defaulters.map((defaulter, index) => (
                  <div key={defaulter.id} className="flex justify-between items-center">
                    <span className="text-sm">{index + 1}. {defaulter.name}</span>
                    <span className="text-sm font-medium text-red-600">
                      ${defaulter.balance.toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Performance Chart */}
        <ClassPerformanceChart className={classData.name} />

        {/* Seating Layout */}
        <Card>
          <CardHeader>
            <CardTitle>Seating Layout</CardTitle>
          </CardHeader>
          <CardContent>
            <ClassSeatingLayout className={classData.name} />
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
};

export default ClassDetail;
