
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DollarSign, Clock, AlertCircle, Plus } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import SalaryPaymentModal from './SalaryPaymentModal';

interface TeacherSalaryCardProps {
  teacherId: string;
  teacherName: string;
  baseSalary?: number;
}

const TeacherSalaryCard = ({ teacherId, teacherName, baseSalary = 0 }: TeacherSalaryCardProps) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { toast } = useToast();

  const { data: salaryData, isLoading, refetch } = useQuery({
    queryKey: ['teacher-salary', teacherId],
    queryFn: async () => {
      const currentMonth = new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      
      const { data: totalPaid, error: totalError } = await supabase
        .from('teacher_salaries')
        .select('amount')
        .eq('teacher_id', teacherId);

      if (totalError) throw totalError;

      const { data: lastPayment, error: lastError } = await supabase
        .from('teacher_salaries')
        .select('*')
        .eq('teacher_id', teacherId)
        .order('paid_on', { ascending: false })
        .limit(1);

      if (lastError) throw lastError;

      const { data: currentMonthPayment, error: currentError } = await supabase
        .from('teacher_salaries')
        .select('*')
        .eq('teacher_id', teacherId)
        .eq('month', currentMonth)
        .single();

      return {
        totalPaid: totalPaid?.reduce((sum, record) => sum + Number(record.amount), 0) || 0,
        lastPayment: lastPayment?.[0] || null,
        currentMonthPaid: !currentError && currentMonthPayment,
        currentMonth
      };
    },
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: 'UGX'
    }).format(amount);
  };

  const getStatusBadge = () => {
    if (salaryData?.currentMonthPaid) {
      return <Badge className="bg-green-100 text-green-800">✅ Paid</Badge>;
    }
    return <Badge variant="destructive">❗ Pending</Badge>;
  };

  if (isLoading) {
    return (
      <Card className="animate-pulse">
        <CardContent className="p-4">
          <div className="h-20 bg-gray-200 rounded"></div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Salary Status
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">This Month ({salaryData?.currentMonth})</span>
            {getStatusBadge()}
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Total Paid</span>
            <span className="font-semibold">{formatCurrency(salaryData?.totalPaid || 0)}</span>
          </div>
          
          {salaryData?.lastPayment && (
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Last Payment</span>
              <div className="text-right">
                <div className="text-sm font-medium">{formatCurrency(salaryData.lastPayment.amount)}</div>
                <div className="text-xs text-muted-foreground">{salaryData.lastPayment.month}</div>
              </div>
            </div>
          )}
          
          <Button 
            onClick={() => setIsModalOpen(true)}
            className="w-full"
            variant={salaryData?.currentMonthPaid ? "outline" : "default"}
          >
            <Plus className="h-4 w-4 mr-2" />
            {salaryData?.currentMonthPaid ? 'Add Payment' : 'Mark as Paid'}
          </Button>
        </CardContent>
      </Card>

      <SalaryPaymentModal
        open={isModalOpen}
        onOpenChange={setIsModalOpen}
        teacherId={teacherId}
        teacherName={teacherName}
        baseSalary={baseSalary}
        onSuccess={() => {
          refetch();
          toast({
            title: "Success",
            description: "Salary payment recorded successfully"
          });
        }}
      />
    </>
  );
};

export default TeacherSalaryCard;
