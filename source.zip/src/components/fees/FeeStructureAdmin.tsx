
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Plus, Edit2, Trash2 } from 'lucide-react';

interface FeeStructure {
  id: string;
  structure_group: string;
  term: string;
  year: string;
  day_fee: number;
  boarding_fee: number;
  transport_fee: number;
  misc_fee: number;
  name: string;
  academic_year: string;
  academic_term: string;
}

interface ClassMapping {
  id: string;
  class_name: string;
  structure_group: string;
}

const FeeStructureAdmin = () => {
  const [feeStructures, setFeeStructures] = useState<FeeStructure[]>([]);
  const [classMappings, setClassMappings] = useState<ClassMapping[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    structure_group: '',
    term: 'Term 1',
    year: new Date().getFullYear().toString(),
    day_fee: 0,
    boarding_fee: 0,
    transport_fee: 0,
    misc_fee: 0,
    name: '',
    academic_year: new Date().getFullYear().toString(),
    academic_term: 'Term 1'
  });

  useEffect(() => {
    fetchFeeStructures();
    fetchClassMappings();
  }, []);

  const fetchFeeStructures = async () => {
    try {
      const { data, error } = await supabase
        .from('fee_structures')
        .select('*')
        .order('structure_group, year, term');

      if (error) throw error;
      setFeeStructures(data || []);
    } catch (error) {
      console.error('Error fetching fee structures:', error);
      toast({
        title: "Error",
        description: "Failed to fetch fee structures",
        variant: "destructive"
      });
    }
  };

  const fetchClassMappings = async () => {
    try {
      const { data, error } = await supabase
        .from('class_fee_mappings')
        .select('*')
        .order('class_name');

      if (error) throw error;
      setClassMappings(data || []);
    } catch (error) {
      console.error('Error fetching class mappings:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingId) {
        const { error } = await supabase
          .from('fee_structures')
          .update(formData)
          .eq('id', editingId);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('fee_structures')
          .insert([formData]);
        if (error) throw error;
      }

      toast({
        title: "Success",
        description: editingId ? "Fee structure updated" : "Fee structure created"
      });

      resetForm();
      fetchFeeStructures();
    } catch (error) {
      console.error('Error saving fee structure:', error);
      toast({
        title: "Error",
        description: "Failed to save fee structure",
        variant: "destructive"
      });
    }
  };

  const handleEdit = (structure: FeeStructure) => {
    setFormData({
      structure_group: structure.structure_group,
      term: structure.term,
      year: structure.year,
      day_fee: structure.day_fee,
      boarding_fee: structure.boarding_fee,
      transport_fee: structure.transport_fee,
      misc_fee: structure.misc_fee,
      name: structure.name,
      academic_year: structure.academic_year,
      academic_term: structure.academic_term
    });
    setEditingId(structure.id);
    setIsCreating(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this fee structure?')) return;

    try {
      const { error } = await supabase
        .from('fee_structures')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Fee structure deleted"
      });
      fetchFeeStructures();
    } catch (error) {
      console.error('Error deleting fee structure:', error);
      toast({
        title: "Error",
        description: "Failed to delete fee structure",
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setFormData({
      structure_group: '',
      term: 'Term 1',
      year: new Date().getFullYear().toString(),
      day_fee: 0,
      boarding_fee: 0,
      transport_fee: 0,
      misc_fee: 0,
      name: '',
      academic_year: new Date().getFullYear().toString(),
      academic_term: 'Term 1'
    });
    setIsCreating(false);
    setEditingId(null);
  };

  const calculateTotal = () => {
    return formData.day_fee + formData.boarding_fee + formData.transport_fee + formData.misc_fee;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Fee Structure Management</h2>
        <Button onClick={() => setIsCreating(true)} className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Create Fee Structure
        </Button>
      </div>

      {isCreating && (
        <Card>
          <CardHeader>
            <CardTitle>{editingId ? 'Edit' : 'Create'} Fee Structure</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Structure Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="e.g., Primary School Fees"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="structure_group">Structure Group</Label>
                  <Input
                    id="structure_group"
                    value={formData.structure_group}
                    onChange={(e) => setFormData({...formData, structure_group: e.target.value})}
                    placeholder="e.g., Primary Lower"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="year">Year</Label>
                  <Input
                    id="year"
                    value={formData.year}
                    onChange={(e) => setFormData({...formData, year: e.target.value, academic_year: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="term">Term</Label>
                  <Select value={formData.term} onValueChange={(value) => setFormData({...formData, term: value, academic_term: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Term 1">Term 1</SelectItem>
                      <SelectItem value="Term 2">Term 2</SelectItem>
                      <SelectItem value="Term 3">Term 3</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="day_fee">Day Student Fee</Label>
                  <Input
                    id="day_fee"
                    type="number"
                    value={formData.day_fee}
                    onChange={(e) => setFormData({...formData, day_fee: parseFloat(e.target.value) || 0})}
                  />
                </div>
                <div>
                  <Label htmlFor="boarding_fee">Boarding Fee</Label>
                  <Input
                    id="boarding_fee"
                    type="number"
                    value={formData.boarding_fee}
                    onChange={(e) => setFormData({...formData, boarding_fee: parseFloat(e.target.value) || 0})}
                  />
                </div>
                <div>
                  <Label htmlFor="transport_fee">Transport Fee</Label>
                  <Input
                    id="transport_fee"
                    type="number"
                    value={formData.transport_fee}
                    onChange={(e) => setFormData({...formData, transport_fee: parseFloat(e.target.value) || 0})}
                  />
                </div>
                <div>
                  <Label htmlFor="misc_fee">Miscellaneous Fee</Label>
                  <Input
                    id="misc_fee"
                    type="number"
                    value={formData.misc_fee}
                    onChange={(e) => setFormData({...formData, misc_fee: parseFloat(e.target.value) || 0})}
                  />
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-lg font-semibold">Total Fee: UGX {calculateTotal().toLocaleString()}</p>
              </div>

              <div className="flex gap-2">
                <Button type="submit">
                  {editingId ? 'Update' : 'Create'} Fee Structure
                </Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Existing Fee Structures</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {feeStructures.map((structure) => (
              <div key={structure.id} className="border rounded-lg p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold">{structure.name}</h3>
                    <p className="text-sm text-gray-600">
                      {structure.structure_group} - {structure.year} {structure.term}
                    </p>
                    <div className="mt-2 grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                      <span>Day: UGX {structure.day_fee.toLocaleString()}</span>
                      <span>Boarding: UGX {structure.boarding_fee.toLocaleString()}</span>
                      <span>Transport: UGX {structure.transport_fee.toLocaleString()}</span>
                      <span>Misc: UGX {structure.misc_fee.toLocaleString()}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(structure)}
                    >
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(structure.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Class to Structure Group Mappings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {classMappings.map((mapping) => (
              <div key={mapping.id} className="border rounded p-3">
                <div className="font-medium">{mapping.class_name}</div>
                <div className="text-sm text-gray-600">{mapping.structure_group}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FeeStructureAdmin;
