
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit, Trash2, Users, DollarSign } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import FeeStructureFormModal from './FeeStructureFormModal';

const FeeStructureManager = () => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingStructure, setEditingStructure] = useState(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch fee structures
  const { data: feeStructures, isLoading } = useQuery({
    queryKey: ['fee-structures'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('fee_structures')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    }
  });

  // Fetch class mappings for each structure
  const { data: classMappings } = useQuery({
    queryKey: ['fee-structure-classes', feeStructures?.map(fs => fs.id)],
    queryFn: async () => {
      if (!feeStructures?.length) return {};
      
      const { data, error } = await supabase
        .from('fee_structure_classes')
        .select(`
          fee_structure_id,
          class_id,
          class_streams!inner(full_name)
        `)
        .in('fee_structure_id', feeStructures.map(fs => fs.id));
      
      if (error) throw error;
      
      // Group by fee_structure_id
      const mappings = {};
      data?.forEach(mapping => {
        if (!mappings[mapping.fee_structure_id]) {
          mappings[mapping.fee_structure_id] = [];
        }
        mappings[mapping.fee_structure_id].push(mapping.class_streams.full_name);
      });
      
      return mappings;
    },
    enabled: !!feeStructures?.length
  });

  // Assign fees to students mutation
  const assignFeesToStudents = useMutation({
    mutationFn: async (structureId: string) => {
      console.log('Starting fee assignment for structure:', structureId);
      
      // Get the fee structure details
      const { data: structure, error: structureError } = await supabase
        .from('fee_structures')
        .select('*')
        .eq('id', structureId)
        .single();
      
      if (structureError) throw structureError;
      console.log('Fee structure:', structure);

      // Get classes assigned to this structure
      const { data: assignedClasses, error: classError } = await supabase
        .from('fee_structure_classes')
        .select(`
          class_streams!inner(full_name)
        `)
        .eq('fee_structure_id', structureId);
      
      if (classError) throw classError;
      
      const classNames = assignedClasses.map(ac => ac.class_streams.full_name);
      console.log('Assigned classes:', classNames);

      if (classNames.length === 0) {
        throw new Error('No classes assigned to this fee structure');
      }

      // Get students in these classes
      const { data: students, error: studentsError } = await supabase
        .from('students')
        .select('id, full_name, class, boarding_status, transport')
        .in('class', classNames);
      
      if (studentsError) throw studentsError;
      console.log('Students found:', students);

      if (students.length === 0) {
        throw new Error('No students found in the assigned classes');
      }

      // Calculate and create student fee records
      const studentFeeRecords = students.map(student => {
        let totalFees = parseFloat(structure.tuition_fee?.toString() || '0');
        
        // Add boarding fee if student is a boarder
        if (student.boarding_status === 'Boarding') {
          totalFees += parseFloat(structure.boarding_fee?.toString() || '0');
        }
        
        // Add transport fee if student uses transport
        if (student.transport === 'Yes') {
          totalFees += parseFloat(structure.transport_fee?.toString() || '0');
        }
        
        // Add other fees
        totalFees += parseFloat(structure.meal_fee?.toString() || '0');
        totalFees += parseFloat(structure.activity_fee?.toString() || '0');
        totalFees += parseFloat(structure.library_fee?.toString() || '0');
        totalFees += parseFloat(structure.computer_fee?.toString() || '0');
        totalFees += parseFloat(structure.medical_fee?.toString() || '0');
        totalFees += parseFloat(structure.development_fee?.toString() || '0');
        totalFees += parseFloat(structure.exam_fee?.toString() || '0');
        totalFees += parseFloat(structure.uniform_fee?.toString() || '0');
        totalFees += parseFloat(structure.misc_fee?.toString() || '0');

        return {
          student_id: student.id,
          fee_structure_id: structureId,
          academic_year: structure.academic_year,
          academic_term: structure.academic_term,
          total_assigned_fees: totalFees,
          total_paid: 0,
          balance: totalFees,
          payment_status: 'Unpaid'
        };
      });

      console.log('Student fee records to create:', studentFeeRecords);

      // Delete existing records for the same academic year and term to avoid duplicates
      for (const student of students) {
        await supabase
          .from('student_fees')
          .delete()
          .eq('student_id', student.id)
          .eq('academic_year', structure.academic_year)
          .eq('academic_term', structure.academic_term);
      }

      // Insert new student fee records
      const { data: insertedRecords, error: insertError } = await supabase
        .from('student_fees')
        .insert(studentFeeRecords)
        .select();

      if (insertError) {
        console.error('Insert error:', insertError);
        throw insertError;
      }

      console.log('Successfully created student fee records:', insertedRecords);
      return insertedRecords;
    },
    onSuccess: (data) => {
      toast({
        title: "Success",
        description: `Successfully assigned fees to ${data?.length || 0} students`
      });
      queryClient.invalidateQueries({ queryKey: ['students-with-fees'] });
      queryClient.invalidateQueries({ queryKey: ['student-fees'] });
    },
    onError: (error) => {
      console.error('Error assigning fees:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to assign fees to students",
        variant: "destructive"
      });
    }
  });

  // Delete fee structure mutation
  const deleteFeeStructure = useMutation({
    mutationFn: async (structureId: string) => {
      // First delete class mappings
      const { error: classMappingError } = await supabase
        .from('fee_structure_classes')
        .delete()
        .eq('fee_structure_id', structureId);
      
      if (classMappingError) throw classMappingError;

      // Then delete the structure
      const { error } = await supabase
        .from('fee_structures')
        .delete()
        .eq('id', structureId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Fee structure deleted successfully"
      });
      queryClient.invalidateQueries({ queryKey: ['fee-structures'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete fee structure",
        variant: "destructive"
      });
    }
  });

  const handleEdit = (structure) => {
    setEditingStructure(structure);
    setIsFormOpen(true);
  };

  const handleFormSuccess = () => {
    setIsFormOpen(false);
    setEditingStructure(null);
    queryClient.invalidateQueries({ queryKey: ['fee-structures'] });
  };

  if (isLoading) {
    return (
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-foreground">Fee Structure Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-16 bg-muted rounded"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="bg-card border-border">
        <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 px-4 sm:px-6">
          <CardTitle className="flex items-center gap-2 text-foreground text-base sm:text-lg">
            <DollarSign className="h-4 w-4 sm:h-5 sm:w-5" />
            Fee Structures
          </CardTitle>
          <Button 
            onClick={() => setIsFormOpen(true)}
            className="flex items-center gap-2 w-full sm:w-auto"
            size="sm"
          >
            <Plus className="h-4 w-4" />
            Create Structure
          </Button>
        </CardHeader>
        <CardContent className="space-y-3 px-3 sm:px-6">
          {!feeStructures || feeStructures.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <p>No fee structures found.</p>
              <p className="text-sm mt-2">Create your first fee structure to get started.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {feeStructures.map((structure) => (
                <div key={structure.id} className="border border-border rounded-lg p-3 sm:p-4 bg-secondary/30">
                  {/* Header */}
                  <div className="flex flex-col sm:flex-row justify-between items-start gap-3 mb-3">
                    <div className="min-w-0 flex-1">
                      <h3 className="font-semibold text-sm sm:text-base text-foreground truncate">{structure.name}</h3>
                      <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                        <Badge variant="outline" className="text-xs">
                          {structure.academic_year} - {structure.academic_term}
                        </Badge>
                        <Badge variant={structure.is_default ? "default" : "secondary"} className="text-xs">
                          {structure.is_default ? "Default" : "Custom"}
                        </Badge>
                        <Badge className="bg-primary/20 text-primary text-xs">
                          {structure.boarding_status}
                        </Badge>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 w-full sm:w-auto">
                      <Button
                        onClick={() => assignFeesToStudents.mutate(structure.id)}
                        disabled={assignFeesToStudents.isPending}
                        size="sm"
                        className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 bg-green-600 hover:bg-green-700 text-xs"
                      >
                        <Users className="h-3.5 w-3.5" />
                        <span className="hidden sm:inline">{assignFeesToStudents.isPending ? 'Assigning...' : 'Assign'}</span>
                        <span className="sm:hidden">{assignFeesToStudents.isPending ? '...' : 'Assign'}</span>
                      </Button>
                      <Button
                        onClick={() => handleEdit(structure)}
                        variant="outline"
                        size="sm"
                        className="p-2"
                      >
                        <Edit className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        onClick={() => deleteFeeStructure.mutate(structure.id)}
                        variant="destructive"
                        size="sm"
                        className="p-2"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>

                  {/* Fee breakdown - Compact grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3 mb-3">
                    <div className="bg-background/50 rounded p-2">
                      <p className="text-[10px] sm:text-xs text-muted-foreground">Tuition</p>
                      <p className="font-medium text-xs sm:text-sm text-foreground">UGX {Number(structure.tuition_fee || 0).toLocaleString()}</p>
                    </div>
                    <div className="bg-background/50 rounded p-2">
                      <p className="text-[10px] sm:text-xs text-muted-foreground">Boarding</p>
                      <p className="font-medium text-xs sm:text-sm text-foreground">UGX {Number(structure.boarding_fee || 0).toLocaleString()}</p>
                    </div>
                    <div className="bg-background/50 rounded p-2">
                      <p className="text-[10px] sm:text-xs text-muted-foreground">Transport</p>
                      <p className="font-medium text-xs sm:text-sm text-foreground">UGX {Number(structure.transport_fee || 0).toLocaleString()}</p>
                    </div>
                    <div className="bg-primary/10 rounded p-2">
                      <p className="text-[10px] sm:text-xs text-muted-foreground">Total</p>
                      <p className="font-medium text-xs sm:text-sm text-primary">
                        UGX {(
                          Number(structure.tuition_fee || 0) +
                          Number(structure.boarding_fee || 0) +
                          Number(structure.transport_fee || 0) +
                          Number(structure.meal_fee || 0) +
                          Number(structure.activity_fee || 0) +
                          Number(structure.library_fee || 0) +
                          Number(structure.computer_fee || 0) +
                          Number(structure.medical_fee || 0) +
                          Number(structure.development_fee || 0) +
                          Number(structure.exam_fee || 0) +
                          Number(structure.uniform_fee || 0) +
                          Number(structure.misc_fee || 0)
                        ).toLocaleString()}
                      </p>
                    </div>
                  </div>

                  {/* Assigned classes */}
                  <div>
                    <p className="text-[10px] sm:text-xs text-muted-foreground mb-1.5">Classes:</p>
                    <div className="flex flex-wrap gap-1">
                      {classMappings?.[structure.id]?.length > 0 ? (
                        classMappings[structure.id].map((className, index) => (
                          <Badge key={index} variant="outline" className="text-[10px]">
                            {className}
                          </Badge>
                        ))
                      ) : (
                        <span className="text-xs text-muted-foreground">No classes assigned</span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Fee Structure Form Modal */}
      {isFormOpen && (
        <FeeStructureFormModal
          isOpen={isFormOpen}
          onClose={() => {
            setIsFormOpen(false);
            setEditingStructure(null);
          }}
          editingStructure={editingStructure}
          onSuccess={handleFormSuccess}
        />
      )}
    </div>
  );
};

export default FeeStructureManager;
