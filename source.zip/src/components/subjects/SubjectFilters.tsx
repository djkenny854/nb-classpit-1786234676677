
import React from 'react';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface SubjectFiltersProps {
  onCategoryChange: (category: string) => void;
  onSearchChange: (search: string) => void;
  selectedCategory: string;
  searchTerm: string;
  categories: string[];
}

const SubjectFilters = ({ 
  onCategoryChange, 
  onSearchChange, 
  selectedCategory,
  searchTerm,
  categories
}: SubjectFiltersProps) => {
  return (
    <div className="flex flex-col md:flex-row gap-4 mb-6">
      <div className="relative w-full md:w-96">
        <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search subjects..."
          className="pl-9"
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
        />
      </div>
      
      <Select 
        value={selectedCategory || 'all'} 
        onValueChange={onCategoryChange}
      >
        <SelectTrigger className="w-full md:w-56">
          <SelectValue placeholder="Filter by category" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Categories</SelectItem>
          {categories.map((category, index) => (
            <SelectItem 
              key={index} 
              value={category || `category-${index}`}
            >
              {category || "Unknown"}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};

export default SubjectFilters;
