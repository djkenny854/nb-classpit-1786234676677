
import React from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Monitor, Calendar, MapPin, User, Hash, DollarSign, Package, Settings, AlertTriangle } from 'lucide-react';

interface InventoryItem {
  id: string;
  name: string;
  description?: string;
  category: string;
  quantity: number;
  cost?: number;
  paid_from_fees: boolean;
  condition: string;
  status: string;
  date_purchased?: string;
  google_device_id?: string;
  enrollment_status: string;
  category_id?: string;
  serial_number?: string;
  location?: string;
  assigned_to?: string;
  warranty_expiry?: string;
  notes?: string;
}

interface InventoryItemDetailsProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item: InventoryItem | null;
  onEdit: (item: InventoryItem) => void;
  onEnroll: (item: InventoryItem) => void;
}

const InventoryItemDetails: React.FC<InventoryItemDetailsProps> = ({
  open,
  onOpenChange,
  item,
  onEdit,
  onEnroll
}) => {
  if (!item) return null;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-green-100 text-green-800';
      case 'in_use': return 'bg-blue-100 text-blue-800';
      case 'maintenance': return 'bg-yellow-100 text-yellow-800';
      case 'retired': return 'bg-gray-100 text-gray-800';
      case 'lost': return 'bg-red-100 text-red-800';
      case 'stolen': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case 'excellent': return 'bg-green-100 text-green-800';
      case 'good': return 'bg-blue-100 text-blue-800';
      case 'fair': return 'bg-yellow-100 text-yellow-800';
      case 'poor': return 'bg-orange-100 text-orange-800';
      case 'damaged': return 'bg-red-100 text-red-800';
      case 'obsolete': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const supportsGoogleEnrollment = (category: string) => {
    return ['Computers', 'Laptops', 'Tablets'].includes(category);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Package className="h-5 w-5" />
            <span>{item.name}</span>
          </DialogTitle>
          <DialogDescription>
            Detailed information about this inventory item
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Category</label>
                  <p className="text-sm font-medium">{item.category}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Quantity</label>
                  <p className="text-sm font-medium">{item.quantity}</p>
                </div>
              </div>
              
              {item.description && (
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Description</label>
                  <p className="text-sm">{item.description}</p>
                </div>
              )}
              
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium text-muted-foreground">Status:</span>
                  <Badge className={getStatusColor(item.status)}>
                    {item.status.replace('_', ' ')}
                  </Badge>
                </div>
                
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium text-muted-foreground">Condition:</span>
                  <Badge className={getConditionColor(item.condition)}>
                    {item.condition}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Financial Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <DollarSign className="h-5 w-5 mr-2" />
                Financial Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Cost per Item</label>
                  <p className="text-sm font-medium">UGX {(item.cost || 0).toLocaleString()}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Total Value</label>
                  <p className="text-sm font-medium">UGX {((item.cost || 0) * item.quantity).toLocaleString()}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <span className="text-sm font-medium text-muted-foreground">Payment Source:</span>
                {item.paid_from_fees ? (
                  <Badge className="bg-yellow-100 text-yellow-800">Student Fees</Badge>
                ) : (
                  <Badge variant="outline">External Funding</Badge>
                )}
              </div>
              
              {item.date_purchased && (
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium text-muted-foreground">Purchase Date:</span>
                  <span className="text-sm">{new Date(item.date_purchased).toLocaleDateString()}</span>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Location and Assignment */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Location & Assignment</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                {item.location && (
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Location</label>
                      <p className="text-sm">{item.location}</p>
                    </div>
                  </div>
                )}
                
                {item.assigned_to && (
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Assigned To</label>
                      <p className="text-sm">{item.assigned_to}</p>
                    </div>
                  </div>
                )}
              </div>
              
              {item.serial_number && (
                <div className="flex items-center space-x-2">
                  <Hash className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Serial Number</label>
                    <p className="text-sm font-mono">{item.serial_number}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Google Device Management */}
          {supportsGoogleEnrollment(item.category) && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Monitor className="h-5 w-5 mr-2" />
                  Google Device Management
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Enrollment Status</label>
                    <p className="text-sm">
                      {item.google_device_id ? (
                        <Badge className="bg-green-100 text-green-800">Enrolled</Badge>
                      ) : (
                        <Badge variant="outline">Not Enrolled</Badge>
                      )}
                    </p>
                  </div>
                  
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => onEnroll(item)}
                  >
                    <Settings className="h-4 w-4 mr-2" />
                    Manage Enrollment
                  </Button>
                </div>
                
                {item.google_device_id && (
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Device ID</label>
                    <p className="text-sm font-mono">{item.google_device_id}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Warranty Information */}
          {item.warranty_expiry && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Warranty Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-2">
                  {new Date(item.warranty_expiry) < new Date() ? (
                    <AlertTriangle className="h-4 w-4 text-orange-600" />
                  ) : (
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                  )}
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Warranty Expiry</label>
                    <p className={`text-sm ${new Date(item.warranty_expiry) < new Date() ? 'text-orange-600 font-medium' : ''}`}>
                      {new Date(item.warranty_expiry).toLocaleDateString()}
                      {new Date(item.warranty_expiry) < new Date() && ' (Expired)'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Notes */}
          {item.notes && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Notes</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">{item.notes}</p>
              </CardContent>
            </Card>
          )}

          {/* Actions */}
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Close
            </Button>
            <Button onClick={() => onEdit(item)}>
              Edit Item
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default InventoryItemDetails;
