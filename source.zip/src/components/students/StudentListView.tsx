import React, { useState } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { CircularProgressbar, buildStyles } from 'react-circular-progressbar';
import { ChevronDown, Edit, Eye, Home, Bus } from 'lucide-react';
import { Student } from '@/types';

interface StudentListViewProps {
  students: Student[];
  onStudentClick: (student: Student) => void;
  onEditStudent: (student: Student) => void;
  loading: boolean;
}

const StudentListView = ({ students, onStudentClick, onEditStudent, loading }: StudentListViewProps) => {
  const [expandedStudents, setExpandedStudents] = useState<Set<string>>(new Set());

  const toggleExpanded = (studentId: string) => {
    const newExpanded = new Set(expandedStudents);
    if (newExpanded.has(studentId)) {
      newExpanded.delete(studentId);
    } else {
      newExpanded.add(studentId);
    }
    setExpandedStudents(newExpanded);
  };

  const getPaymentPercentage = (student: Student) => {
    const totalFees = student.fees.paid + student.fees.due;
    if (totalFees === 0) return 0;
    return Math.round((student.fees.paid / totalFees) * 100);
  };

  const getFeeStatusColor = (student: Student) => {
    const percentage = getPaymentPercentage(student);
    if (percentage === 100) return 'hsl(var(--primary))';
    if (percentage > 0) return 'hsl(var(--muted-foreground))';
    return 'hsl(var(--destructive))';
  };

  const getFeeStatusText = (student: Student) => {
    const percentage = getPaymentPercentage(student);
    if (percentage === 100) return 'Paid';
    if (percentage > 0) return 'Partial';
    return 'Due';
  };

  const getFeeStatusVariant = (student: Student): "default" | "secondary" | "outline" => {
    const percentage = getPaymentPercentage(student);
    if (percentage === 100) return 'default';
    if (percentage > 0) return 'secondary';
    return 'outline';
  };

  if (loading) {
    return (
      <div className="space-y-2">
        {[...Array(6)].map((_, i) => (
          <Card key={i} className="w-full animate-pulse bg-card border-border">
            <CardContent className="p-3">
              <div className="flex items-center gap-3">
                <div className="rounded-full bg-muted h-10 w-10"></div>
                <div className="flex-1 space-y-1.5">
                  <div className="h-3.5 bg-muted rounded w-1/3"></div>
                  <div className="h-2.5 bg-muted rounded w-1/5"></div>
                </div>
                <div className="h-8 w-8 bg-muted rounded-full"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (students.length === 0) {
    return (
      <Card className="w-full bg-card border-border">
        <CardContent className="p-8 text-center">
          <div className="text-muted-foreground text-base mb-1">No students found</div>
          <div className="text-muted-foreground/70 text-sm">Try adjusting your filters</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <TooltipProvider>
      <div className="space-y-2">
        {students.map((student) => {
          const isExpanded = expandedStudents.has(student.id);
          const percentage = getPaymentPercentage(student);
          
          return (
            <Collapsible key={student.id} open={isExpanded} onOpenChange={() => toggleExpanded(student.id)}>
              <Card className="w-full bg-card border-border hover:bg-secondary/30 transition-colors">
                <CollapsibleTrigger asChild>
                  <CardContent className="p-3 cursor-pointer">
                    <div className="flex items-center gap-2 sm:gap-3">
                      {/* Avatar - Smaller on mobile */}
                      <Avatar className="h-9 w-9 sm:h-10 sm:w-10 border border-border flex-shrink-0">
                        <AvatarImage src={student.profileImage} alt={student.name} />
                        <AvatarFallback className="bg-muted text-foreground text-xs font-semibold">
                          {student.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      
                      {/* Name & ID */}
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-sm text-foreground truncate">{student.name}</h3>
                        <div className="flex items-center gap-1.5 text-[10px] sm:text-xs text-muted-foreground">
                          <span className="truncate">{student.className}</span>
                          <span className="hidden sm:inline">•</span>
                          <span className="hidden sm:inline truncate">{student.enrollmentNumber}</span>
                        </div>
                      </div>

                      {/* Status Badges - Hidden on small screens */}
                      <div className="hidden md:flex items-center gap-1.5">
                        {student.boardingStatus === 'Boarding' && (
                          <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                            <Home className="h-3 w-3 mr-0.5" />
                            B
                          </Badge>
                        )}
                        {student.transportUse === 'Yes' && (
                          <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                            <Bus className="h-3 w-3 mr-0.5" />
                            T
                          </Badge>
                        )}
                      </div>

                      {/* Fee Progress - Compact */}
                      <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
                        <div className="w-8 h-8 sm:w-9 sm:h-9">
                          <CircularProgressbar
                            value={percentage}
                            text={`${percentage}%`}
                            styles={buildStyles({
                              textSize: '24px',
                              pathColor: getFeeStatusColor(student),
                              textColor: getFeeStatusColor(student),
                              trailColor: 'hsl(var(--muted))',
                              backgroundColor: 'transparent',
                            })}
                          />
                        </div>
                        <Badge variant={getFeeStatusVariant(student)} className="text-[10px] hidden sm:inline-flex">
                          {getFeeStatusText(student)}
                        </Badge>
                      </div>

                      {/* Action Buttons - Compact */}
                      <div className="flex items-center gap-0.5 flex-shrink-0">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground hover:bg-accent"
                              onClick={(e) => {
                                e.stopPropagation();
                                onStudentClick(student);
                              }}
                            >
                              <Eye className="h-3.5 w-3.5" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>View</TooltipContent>
                        </Tooltip>

                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground hover:bg-accent"
                              onClick={(e) => {
                                e.stopPropagation();
                                onEditStudent(student);
                              }}
                            >
                              <Edit className="h-3.5 w-3.5" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Edit</TooltipContent>
                        </Tooltip>
                      </div>

                      {/* Expand Arrow */}
                      <ChevronDown 
                        className={`h-4 w-4 text-muted-foreground transition-transform duration-200 flex-shrink-0 ${
                          isExpanded ? 'rotate-180' : ''
                        }`} 
                      />
                    </div>
                  </CardContent>
                </CollapsibleTrigger>

                {/* Expanded Content */}
                <CollapsibleContent>
                  <div className="px-3 pb-3 border-t border-border">
                    <div className="pt-3 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                      <div>
                        <p className="font-medium text-foreground mb-1">Personal</p>
                        <p className="text-muted-foreground">Gender: {student.gender || 'N/A'}</p>
                        <p className="text-muted-foreground">DOB: {student.dateOfBirth || 'N/A'}</p>
                      </div>
                      
                      <div>
                        <p className="font-medium text-foreground mb-1">Contact</p>
                        <p className="text-muted-foreground truncate">Phone: {student.parentContact || 'N/A'}</p>
                        <p className="text-muted-foreground truncate">Parent: {student.parentName || 'N/A'}</p>
                      </div>
                      
                      <div>
                        <p className="font-medium text-foreground mb-1">Fees</p>
                        <p className="text-green-500">Paid: UGX {student.fees.paid.toLocaleString()}</p>
                        <p className="text-destructive">Due: UGX {student.fees.due.toLocaleString()}</p>
                      </div>
                      
                      <div>
                        <p className="font-medium text-foreground mb-1">Status</p>
                        <p className="text-muted-foreground">{student.boardingStatus}</p>
                        <p className="text-muted-foreground">Transport: {student.transportUse || 'No'}</p>
                      </div>
                    </div>
                  </div>
                </CollapsibleContent>
              </Card>
            </Collapsible>
          );
        })}
      </div>
    </TooltipProvider>
  );
};

export default StudentListView;
