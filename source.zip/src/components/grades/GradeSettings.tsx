import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Plus, Edit, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { getAssessmentCategories, createAssessmentCategory } from '@/utils/gradingService';
import { supabase } from '@/integrations/supabase/client';
import type { AssessmentCategory } from '@/types/grading';

const GradeSettings = () => {
  const [categories, setCategories] = useState<AssessmentCategory[]>([]);
  const [newCategory, setNewCategory] = useState({ name: '', description: '', weight: 1 });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    try {
      const data = await getAssessmentCategories();
      setCategories(data);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load assessment categories",
        variant: "destructive"
      });
    }
  };

  const handleAddCategory = async () => {
    if (!newCategory.name.trim()) return;
    
    setLoading(true);
    try {
      await createAssessmentCategory({
        name: newCategory.name,
        description: newCategory.description,
        weight: newCategory.weight,
        is_active: true
      });
      
      setNewCategory({ name: '', description: '', weight: 1 });
      loadCategories();
      
      toast({
        title: "Success",
        description: "Assessment category created successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create assessment category",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const toggleCategoryStatus = async (id: string, isActive: boolean) => {
    try {
      await supabase
        .from('assessment_categories')
        .update({ is_active: !isActive })
        .eq('id', id);
      
      loadCategories();
      
      toast({
        title: "Success",
        description: `Category ${!isActive ? 'activated' : 'deactivated'} successfully`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update category status",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Grading Settings</h2>
        <p className="text-muted-foreground">Configure assessment categories, grading scales, and system preferences</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Grading Scale</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-3">
              <div className="flex justify-between items-center p-3 border rounded-lg">
                <div>
                  <span className="font-medium">A Grade</span>
                  <p className="text-sm text-muted-foreground">Excellent performance</p>
                </div>
                <Badge className="bg-green-100 text-green-800">80-100%</Badge>
              </div>
              <div className="flex justify-between items-center p-3 border rounded-lg">
                <div>
                  <span className="font-medium">B Grade</span>
                  <p className="text-sm text-muted-foreground">Very good performance</p>
                </div>
                <Badge className="bg-blue-100 text-blue-800">70-79%</Badge>
              </div>
              <div className="flex justify-between items-center p-3 border rounded-lg">
                <div>
                  <span className="font-medium">C Grade</span>
                  <p className="text-sm text-muted-foreground">Good performance</p>
                </div>
                <Badge className="bg-yellow-100 text-yellow-800">60-69%</Badge>
              </div>
              <div className="flex justify-between items-center p-3 border rounded-lg">
                <div>
                  <span className="font-medium">D Grade</span>
                  <p className="text-sm text-muted-foreground">Fair performance</p>
                </div>
                <Badge className="bg-orange-100 text-orange-800">50-59%</Badge>
              </div>
              <div className="flex justify-between items-center p-3 border rounded-lg">
                <div>
                  <span className="font-medium">F Grade</span>
                  <p className="text-sm text-muted-foreground">Below standard</p>
                </div>
                <Badge className="bg-red-100 text-red-800">0-49%</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Assessment Types</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {['Exam', 'Assignment', 'Test', 'Quiz', 'Project', 'Presentation', 'Practical', 'Homework', 'Classwork'].map(type => (
              <div key={type} className="flex justify-between items-center p-2 border rounded">
                <span>{type}</span>
                <Switch defaultChecked />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Assessment Categories</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="category-name">Category Name</Label>
              <Input
                id="category-name"
                value={newCategory.name}
                onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                placeholder="e.g., Continuous Assessment"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="category-weight">Weight</Label>
              <Input
                id="category-weight"
                type="number"
                min="0"
                max="1"
                step="0.1"
                value={newCategory.weight}
                onChange={(e) => setNewCategory({ ...newCategory, weight: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="add-button" className="opacity-0">Add</Label>
              <Button 
                id="add-button"
                onClick={handleAddCategory}
                disabled={loading || !newCategory.name.trim()}
                className="w-full"
              >
                <Plus className="mr-2 h-4 w-4" />
                Add Category
              </Button>
            </div>
          </div>

          <div className="space-y-3">
            {categories.map(category => (
              <div key={category.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <h4 className="font-medium">{category.name}</h4>
                    <Badge variant={category.is_active ? "default" : "secondary"}>
                      Weight: {category.weight}
                    </Badge>
                    {!category.is_active && (
                      <Badge variant="outline">Inactive</Badge>
                    )}
                  </div>
                  {category.description && (
                    <p className="text-sm text-muted-foreground mt-1">{category.description}</p>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={category.is_active}
                    onCheckedChange={() => toggleCategoryStatus(category.id, category.is_active)}
                  />
                  <Button variant="outline" size="sm">
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GradeSettings;