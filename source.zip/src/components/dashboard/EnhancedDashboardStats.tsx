import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Users, DollarSign, Clock, AlertTriangle, TrendingUp, BookOpen, CheckCircle, GraduationCap } from 'lucide-react';
import CompactStats from '@/components/common/CompactStats';

const EnhancedDashboardStats = () => {
  // Fetch students count
  const { data: studentsCount = 0 } = useQuery({
    queryKey: ['students-count'],
    queryFn: async () => {
      const { count } = await supabase
        .from('students')
        .select('*', { count: 'exact', head: true });
      return count || 0;
    }
  });

  // Fetch teachers count
  const { data: teachersCount = 0 } = useQuery({
    queryKey: ['teachers-count'],
    queryFn: async () => {
      const { count } = await supabase
        .from('teachers')
        .select('*', { count: 'exact', head: true });
      return count || 0;
    }
  });

  // Fetch total revenue from payments
  const { data: totalRevenue = 0 } = useQuery({
    queryKey: ['total-revenue'],
    queryFn: async () => {
      const { data } = await supabase
        .from('payments')
        .select('amount');
      return data?.reduce((sum, payment) => sum + Number(payment.amount), 0) || 0;
    }
  });

  // Fetch pending attendance
  const { data: pendingAttendance = 0 } = useQuery({
    queryKey: ['pending-attendance'],
    queryFn: async () => {
      const today = new Date().toISOString().split('T')[0];
      const { data: todayAttendance } = await supabase
        .from('attendance')
        .select('student_id')
        .eq('date', today);
      
      const markedStudents = todayAttendance?.length || 0;
      return studentsCount - markedStudents;
    }
  });

  // Fetch pending salaries
  const { data: pendingSalaries = 0 } = useQuery({
    queryKey: ['pending-salaries'],
    queryFn: async () => {
      const currentMonth = new Date().toISOString().slice(0, 7);
      const { data: paidSalaries } = await supabase
        .from('teacher_salaries')
        .select('teacher_id')
        .like('month', `${currentMonth}%`);
      
      const paidTeachers = paidSalaries?.length || 0;
      return teachersCount - paidTeachers;
    }
  });

  // Calculate monthly revenue growth
  const { data: monthlyGrowth = 0 } = useQuery({
    queryKey: ['monthly-growth'],
    queryFn: async () => {
      const currentMonth = new Date().toISOString().slice(0, 7);
      const lastMonth = new Date(new Date().setMonth(new Date().getMonth() - 1)).toISOString().slice(0, 7);
      
      const { data: currentMonthPayments } = await supabase
        .from('payments')
        .select('amount')
        .gte('created_at', `${currentMonth}-01`)
        .lt('created_at', `${new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().slice(0, 7)}-01`);
      
      const { data: lastMonthPayments } = await supabase
        .from('payments')
        .select('amount')
        .gte('created_at', `${lastMonth}-01`)
        .lt('created_at', `${currentMonth}-01`);
      
      const currentTotal = currentMonthPayments?.reduce((sum, p) => sum + Number(p.amount), 0) || 0;
      const lastTotal = lastMonthPayments?.reduce((sum, p) => sum + Number(p.amount), 0) || 0;
      
      if (lastTotal === 0) return 0;
      return Math.round(((currentTotal - lastTotal) / lastTotal) * 100);
    }
  });

  // Fetch subjects count
  const { data: subjectsCount = 0 } = useQuery({
    queryKey: ['subjects-count'],
    queryFn: async () => {
      const { count } = await supabase
        .from('subjects')
        .select('*', { count: 'exact', head: true });
      return count || 0;
    }
  });

  const stats = [
    {
      label: 'Total Students',
      value: studentsCount,
      icon: <Users className="h-5 w-5" />,
      trend: { value: 12, isPositive: true }
    },
    {
      label: 'Total Revenue',
      value: `UGX ${totalRevenue.toLocaleString()}`,
      icon: <DollarSign className="h-5 w-5" />,
      trend: { value: monthlyGrowth, isPositive: monthlyGrowth >= 0 }
    },
    {
      label: 'Pending Attendance',
      value: pendingAttendance,
      icon: <Clock className="h-5 w-5" />
    },
    {
      label: 'Pending Salaries',
      value: pendingSalaries,
      icon: <AlertTriangle className="h-5 w-5" />
    },
    {
      label: 'Active Teachers',
      value: teachersCount,
      icon: <GraduationCap className="h-5 w-5" />,
      trend: { value: 8, isPositive: true }
    },
    {
      label: 'Subjects',
      value: subjectsCount,
      icon: <BookOpen className="h-5 w-5" />
    },
    {
      label: 'Monthly Growth',
      value: `${monthlyGrowth}%`,
      icon: <TrendingUp className="h-5 w-5" />,
      trend: { value: Math.abs(monthlyGrowth), isPositive: monthlyGrowth >= 0 }
    },
    {
      label: 'System Health',
      value: 'Excellent',
      icon: <CheckCircle className="h-5 w-5" />
    }
  ];

  return <CompactStats stats={stats} />;
};

export default EnhancedDashboardStats;
