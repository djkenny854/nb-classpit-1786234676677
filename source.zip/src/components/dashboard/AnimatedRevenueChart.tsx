
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { supabase } from '@/integrations/supabase/client';
import { TrendingUp, DollarSign } from 'lucide-react';

const chartConfig = {
  revenue: {
    label: 'Revenue',
    color: 'hsl(var(--primary))',
  },
  fees: {
    label: 'Fee Collections',
    color: 'hsl(var(--chart-2))',
  }
};

const AnimatedRevenueChart = () => {
  const { data: revenueData = [] } = useQuery({
    queryKey: ['revenue-chart-data'],
    queryFn: async () => {
      // Get last 12 months of revenue data
      const months = [];
      const currentDate = new Date();
      
      for (let i = 11; i >= 0; i--) {
        const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
        const monthStr = date.toISOString().slice(0, 7);
        const monthName = date.toLocaleDateString('en-US', { month: 'short' });
        
        const nextMonth = new Date(date.getFullYear(), date.getMonth() + 1, 1);
        
        const { data: payments } = await supabase
          .from('payments')
          .select('amount')
          .gte('created_at', `${monthStr}-01`)
          .lt('created_at', nextMonth.toISOString().slice(0, 10));
        
        const { data: feeTransactions } = await supabase
          .from('fee_transactions')
          .select('amount')
          .gte('created_at', `${monthStr}-01`)
          .lt('created_at', nextMonth.toISOString().slice(0, 10));
        
        const paymentTotal = payments?.reduce((sum, p) => sum + Number(p.amount), 0) || 0;
        const feeTotal = feeTransactions?.reduce((sum, f) => sum + Number(f.amount), 0) || 0;
        
        months.push({
          month: monthName,
          revenue: paymentTotal,
          fees: feeTotal,
          total: paymentTotal + feeTotal
        });
      }
      
      return months;
    },
    refetchInterval: 5 * 60 * 1000, // Refresh every 5 minutes
  });

  const totalRevenue = revenueData.reduce((sum, item) => sum + item.total, 0);
  const avgMonthly = totalRevenue / (revenueData.length || 1);

  return (
    <Card className="col-span-full lg:col-span-2 backdrop-blur-sm bg-card border border-border shadow-lg animate-scale-in overflow-hidden">
      <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between space-y-2 sm:space-y-0 pb-2 px-3 sm:px-6">
        <div className="min-w-0">
          <CardTitle className="text-base sm:text-lg font-bold flex items-center gap-2 text-foreground">
            <TrendingUp className="h-4 w-4 sm:h-5 sm:w-5 text-primary flex-shrink-0" />
            <span className="truncate">Revenue Analytics</span>
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-1 hidden sm:block">
            Monthly revenue trends
          </p>
        </div>
        <div className="text-left sm:text-right">
          <div className="flex items-center gap-1 text-lg sm:text-xl font-bold text-primary">
            <DollarSign className="h-4 w-4" />
            {avgMonthly.toLocaleString()}
          </div>
          <p className="text-xs text-muted-foreground">Avg/month</p>
        </div>
      </CardHeader>
      <CardContent className="pt-2 px-2 sm:px-6">
        <ChartContainer config={chartConfig} className="h-[180px] sm:h-[220px] lg:h-[260px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={revenueData} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0.05}/>
                </linearGradient>
                <linearGradient id="feesGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--chart-2))" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="hsl(var(--chart-2))" stopOpacity={0.05}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="month" 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
              />
              <ChartTooltip 
                content={<ChartTooltipContent />}
                formatter={(value: number) => [`UGX ${value.toLocaleString()}`, '']}
              />
              <Area 
                type="monotone" 
                dataKey="fees" 
                stackId="1"
                stroke="hsl(var(--chart-2))" 
                fill="url(#feesGradient)"
                strokeWidth={2}
              />
              <Area 
                type="monotone" 
                dataKey="revenue" 
                stackId="1"
                stroke="hsl(var(--primary))" 
                fill="url(#revenueGradient)"
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </ChartContainer>
        
        <div className="flex flex-wrap items-center gap-3 sm:gap-4 mt-3 pt-3 border-t border-border">
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-primary"></div>
            <span className="text-xs text-muted-foreground">Payments</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-chart-2"></div>
            <span className="text-xs text-muted-foreground">Fees</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AnimatedRevenueChart;
