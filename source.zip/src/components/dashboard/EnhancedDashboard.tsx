import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, GraduationCap, BookOpen, DollarSign, Calendar, TrendingUp, Clock, CheckCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import FinancialVisuals from './FinancialVisuals';
import AttendanceOverview from './AttendanceOverview';

interface DashboardStats {
  totalStudents: number;
  totalTeachers: number;
  activeSubjects: number;
  totalClasses: number;
  financialStats: {
    todayPayments: {
      studentsCount: number;
      totalAmount: number;
      transactions: number;
    };
    monthlyPayments: {
      studentsCount: number;
      totalAmount: number;
      transactions: number;
    };
    feeStatus: {
      paid: number;
      partial: number;
      unpaid: number;
    };
    weeklyTrend: Array<{
      day: string;
      amount: number;
      students: number;
    }>;
  };
  attendanceData: Array<{
    className: string;
    totalStudents: number;
    present: number;
    absent: number;
    percentage: number;
    attendanceTaken: boolean;
  }>;
  todayAttendance: {
    present: number;
    absent: number;
    total: number;
    percentage: number;
  };
  todayFeeCollection: {
    amount: number;
    transactions: number;
  };
  weeklyFeeCollection: {
    amount: number;
    transactions: number;
  };
  monthlyFeeCollection: {
    amount: number;
    transactions: number;
  };
  pendingFees: {
    amount: number;
    students: number;
  };
  recentExamResults: Array<{
    exam_name: string;
    average_score: number;
    total_students: number;
  }>;
  upcomingExams: Array<{
    exam_name: string;
    exam_date: string;
    subject_name: string;
    class_name: string;
  }>;
}

const EnhancedDashboard = () => {
  const [stats, setStats] = useState<DashboardStats>({
    totalStudents: 0,
    totalTeachers: 0,
    activeSubjects: 0,
    totalClasses: 0,
    financialStats: {
      todayPayments: { studentsCount: 0, totalAmount: 0, transactions: 0 },
      monthlyPayments: { studentsCount: 0, totalAmount: 0, transactions: 0 },
      feeStatus: { paid: 0, partial: 0, unpaid: 0 },
      weeklyTrend: []
    },
    attendanceData: [],
    todayAttendance: { present: 0, absent: 0, total: 0, percentage: 0 },
    todayFeeCollection: { amount: 0, transactions: 0 },
    weeklyFeeCollection: { amount: 0, transactions: 0 },
    monthlyFeeCollection: { amount: 0, transactions: 0 },
    pendingFees: { amount: 0, students: 0 },
    recentExamResults: [],
    upcomingExams: []
  });
  
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchDashboardStats();
  }, []);

  const fetchDashboardStats = async () => {
    try {
      setLoading(true);
      
      const today = new Date().toISOString().split('T')[0];
      const startOfWeek = new Date();
      startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
      const weekStart = startOfWeek.toISOString().split('T')[0];
      
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      const monthStart = startOfMonth.toISOString().split('T')[0];

      // Fetch basic counts
      const [studentsRes, teachersRes, subjectsRes, classesRes] = await Promise.all([
        supabase.from('students').select('*', { count: 'exact', head: true }),
        supabase.from('teachers').select('*', { count: 'exact', head: true }),
        supabase.from('enhanced_subjects').select('*', { count: 'exact', head: true }).eq('is_active', true),
        supabase.from('class_streams').select('*', { count: 'exact', head: true })
      ]);

      // Fetch financial data
      const financialStats = await fetchFinancialStats(today, weekStart, monthStart);

      // Fetch attendance data
      const attendanceData = await fetchAttendanceData(today);

      // Fetch today's attendance
      const { data: todayAttendanceData } = await supabase
        .from('attendance')
        .select('status')
        .eq('date', today);

      const presentToday = todayAttendanceData?.filter(a => a.status === 'present').length || 0;
      const absentToday = todayAttendanceData?.filter(a => a.status === 'absent').length || 0;
      const totalAttendanceToday = todayAttendanceData?.length || 0;

      // Fetch fee collections from fee_transactions table
      const [todayFeesRes, weeklyFeesRes, monthlyFeesRes] = await Promise.all([
        supabase
          .from('fee_transactions')
          .select('amount')
          .gte('payment_date', today)
          .lt('payment_date', new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()),
        supabase
          .from('fee_transactions')
          .select('amount')
          .gte('payment_date', weekStart),
        supabase
          .from('fee_transactions')
          .select('amount')
          .gte('payment_date', monthStart)
      ]);

      const todayFees = todayFeesRes.data?.reduce((sum, p) => sum + Number(p.amount), 0) || 0;
      const weeklyFees = weeklyFeesRes.data?.reduce((sum, p) => sum + Number(p.amount), 0) || 0;
      const monthlyFees = monthlyFeesRes.data?.reduce((sum, p) => sum + Number(p.amount), 0) || 0;

      // Fetch pending fees from student_fees table
      const { data: pendingFeesData, error: pendingFeesError } = await supabase
        .from('student_fees')
        .select('balance')
        .gt('balance', 0);

      if (pendingFeesError) throw pendingFeesError;

      const totalPendingAmount = pendingFeesData?.reduce((sum, fee) => sum + (fee.balance || 0), 0) || 0;
      const studentsWithPendingFees = pendingFeesData?.length || 0;

      // Fetch recent exam results
      const { data: recentExamResultsData } = await supabase
        .from('exam_results')
        .select('exam_name, average_marks')
        .order('date_entered', { ascending: false })
        .limit(100);

      // Process exam results
      const examResults = recentExamResultsData?.reduce((acc: any, result: any) => {
        const examName = result.exam_name;
        if (!examName) return acc;
        
        if (!acc[examName]) {
          acc[examName] = { total_students: 0, sum_average_marks: 0 };
        }
        
        acc[examName].sum_average_marks += result.average_marks;
        acc[examName].total_students++;
        
        return acc;
      }, {});

      const processedExamResults = Object.entries(examResults || {}).map(([exam_name, data]: [string, any]) => ({
        exam_name,
        average_score: data.sum_average_marks / data.total_students,
        total_students: data.total_students
      })).slice(0, 5);

      // Fetch upcoming exams
      const { data: upcomingExamsData } = await supabase
        .from('exams')
        .select('name, start_date, term')
        .gte('start_date', today)
        .order('start_date', { ascending: true })
        .limit(5);

      setStats(prevStats => ({
        ...prevStats,
        totalStudents: studentsRes.count || 0,
        totalTeachers: teachersRes.count || 0,
        activeSubjects: subjectsRes.count || 0,
        totalClasses: classesRes.count || 0,
        financialStats,
        attendanceData,
        todayAttendance: {
          present: presentToday,
          absent: absentToday,
          total: totalAttendanceToday,
          percentage: totalAttendanceToday > 0 ? (presentToday / totalAttendanceToday) * 100 : 0
        },
        todayFeeCollection: {
          amount: todayFees,
          transactions: todayFeesRes.data?.length || 0
        },
        weeklyFeeCollection: {
          amount: weeklyFees,
          transactions: weeklyFeesRes.data?.length || 0
        },
        monthlyFeeCollection: {
          amount: monthlyFees,
          transactions: monthlyFeesRes.data?.length || 0
        },
        pendingFees: {
          amount: totalPendingAmount,
          students: studentsWithPendingFees
        },
        recentExamResults: processedExamResults,
        upcomingExams: upcomingExamsData?.map(exam => ({
          exam_name: exam.name,
          exam_date: exam.start_date,
          subject_name: exam.term,
          class_name: '' // This info is no longer available on the exams table
        })) || []
      }));

    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      toast({
        title: "Error",
        description: "Failed to fetch dashboard statistics",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchFinancialStats = async (today: string, weekStart: string, monthStart: string) => {
    // Fetch today's payments with unique students count
    const { data: todayTransactions } = await supabase
      .from('fee_transactions')
      .select('student_id, amount')
      .gte('payment_date', today)
      .lt('payment_date', new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString());

    const todayUniqueStudents = new Set(todayTransactions?.map(t => t.student_id) || []).size;
    const todayTotal = todayTransactions?.reduce((sum, t) => sum + Number(t.amount), 0) || 0;

    // Fetch monthly payments with unique students count
    const { data: monthlyTransactions } = await supabase
      .from('fee_transactions')
      .select('student_id, amount')
      .gte('payment_date', monthStart);

    const monthlyUniqueStudents = new Set(monthlyTransactions?.map(t => t.student_id) || []).size;
    const monthlyTotal = monthlyTransactions?.reduce((sum, t) => sum + Number(t.amount), 0) || 0;

    // Fetch fee status distribution
    const { data: feeStatusData } = await supabase
      .from('students')
      .select('fee_status');

    const feeStatus = {
      paid: feeStatusData?.filter(s => s.fee_status === 'Paid').length || 0,
      partial: feeStatusData?.filter(s => s.fee_status === 'Partial').length || 0,
      unpaid: feeStatusData?.filter(s => s.fee_status === 'Unpaid').length || 0
    };

    // Generate weekly trend data
    const weeklyTrend = [];
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    
    for (let i = 0; i < 7; i++) {
      const date = new Date();
      date.setDate(date.getDate() - (6 - i));
      const dateStr = date.toISOString().split('T')[0];
      
      const { data: dayTransactions } = await supabase
        .from('fee_transactions')
        .select('student_id, amount')
        .gte('payment_date', dateStr)
        .lt('payment_date', new Date(date.getTime() + 24 * 60 * 60 * 1000).toISOString());

      weeklyTrend.push({
        day: dayNames[date.getDay()],
        amount: dayTransactions?.reduce((sum, t) => sum + Number(t.amount), 0) || 0,
        students: new Set(dayTransactions?.map(t => t.student_id) || []).size
      });
    }

    return {
      todayPayments: {
        studentsCount: todayUniqueStudents,
        totalAmount: todayTotal,
        transactions: todayTransactions?.length || 0
      },
      monthlyPayments: {
        studentsCount: monthlyUniqueStudents,
        totalAmount: monthlyTotal,
        transactions: monthlyTransactions?.length || 0
      },
      feeStatus,
      weeklyTrend
    };
  };

  const fetchAttendanceData = async (today: string) => {
    // Get all classes
    const { data: classes } = await supabase
      .from('class_streams')
      .select('full_name');

    if (!classes) return [];

    const attendanceData = [];

    for (const classStream of classes) {
      // Get students in this class
      const { data: students } = await supabase
        .from('students')
        .select('id')
        .eq('class', classStream.full_name);

      const totalStudents = students?.length || 0;

      // Get today's attendance for this class
      const studentIds = students?.map(s => s.id) || [];
      
      if (studentIds.length > 0) {
        const { data: attendance } = await supabase
          .from('attendance')
          .select('status')
          .eq('date', today)
          .in('student_id', studentIds);

        const attendanceTaken = (attendance?.length || 0) > 0;
        const present = attendance?.filter(a => a.status === 'present').length || 0;
        const absent = attendance?.filter(a => a.status === 'absent').length || 0;
        const percentage = attendanceTaken && totalStudents > 0 ? (present / totalStudents) * 100 : 0;

        attendanceData.push({
          className: classStream.full_name,
          totalStudents,
          present,
          absent,
          percentage,
          attendanceTaken
        });
      } else {
        attendanceData.push({
          className: classStream.full_name,
          totalStudents: 0,
          present: 0,
          absent: 0,
          percentage: 0,
          attendanceTaken: false
        });
      }
    }

    return attendanceData;
  };

  const formatCurrency = (amount: number) => {
    return `UGX ${amount.toLocaleString()}`;
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map(i => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-3">
                  <div className="h-4 bg-muted rounded w-3/4"></div>
                  <div className="h-8 bg-muted rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Enhanced Dashboard</h1>
        <div className="text-sm text-muted-foreground">
          {new Date().toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Students</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalStudents}</div>
            <p className="text-xs text-muted-foreground">Enrolled students</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Teachers</CardTitle>
            <GraduationCap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalTeachers}</div>
            <p className="text-xs text-muted-foreground">Teaching staff</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Subjects</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeSubjects}</div>
            <p className="text-xs text-muted-foreground">Available subjects</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Classes</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalClasses}</div>
            <p className="text-xs text-muted-foreground">Class streams</p>
          </CardContent>
        </Card>
      </div>

      {/* Enhanced Visuals Tabs */}
      <Tabs defaultValue="financial" className="space-y-4">
        <TabsList>
          <TabsTrigger value="financial">Financial Overview</TabsTrigger>
          <TabsTrigger value="attendance">Attendance Overview</TabsTrigger>
          <TabsTrigger value="summary">Quick Summary</TabsTrigger>
        </TabsList>

        <TabsContent value="financial" className="space-y-4">
          <FinancialVisuals stats={stats.financialStats} />
        </TabsContent>

        <TabsContent value="attendance" className="space-y-4">
          <AttendanceOverview attendanceData={stats.attendanceData} />
        </TabsContent>

        <TabsContent value="summary" className="space-y-4">
          {/* Keep existing summary content */}
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5" />
                  Today's Attendance
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                  <div>
                    <p className="font-medium text-green-800">Present Students</p>
                    <p className="text-sm text-green-600">Out of {stats.todayAttendance.total} recorded</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-green-700">{stats.todayAttendance.present}</p>
                    <p className="text-sm text-green-600">{stats.todayAttendance.percentage.toFixed(1)}%</p>
                  </div>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                  <div>
                    <p className="font-medium text-red-800">Absent Students</p>
                    <p className="text-sm text-red-600">Marked absent today</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-red-700">{stats.todayAttendance.absent}</p>
                    <p className="text-sm text-red-600">{(100 - stats.todayAttendance.percentage).toFixed(1)}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Fee Collection Overview
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                  <div>
                    <p className="font-medium text-blue-800">Today's Collection</p>
                    <p className="text-sm text-blue-600">{stats.todayFeeCollection.transactions} transactions</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-blue-700">{formatCurrency(stats.todayFeeCollection.amount)}</p>
                  </div>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                  <div>
                    <p className="font-medium text-purple-800">This Week</p>
                    <p className="text-sm text-purple-600">{stats.weeklyFeeCollection.transactions} transactions</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-bold text-purple-700">{formatCurrency(stats.weeklyFeeCollection.amount)}</p>
                  </div>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-orange-50 rounded-lg">
                  <div>
                    <p className="font-medium text-orange-800">This Month</p>
                    <p className="text-sm text-orange-600">{stats.monthlyFeeCollection.transactions} transactions</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-bold text-orange-700">{formatCurrency(stats.monthlyFeeCollection.amount)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Academic Performance & Upcoming Events */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Recent Exam Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {stats.recentExamResults.length > 0 ? (
                stats.recentExamResults.map((exam, index) => (
                  <div key={index} className="flex justify-between items-center p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">{exam.exam_name}</p>
                      <p className="text-sm text-muted-foreground">{exam.total_students} students</p>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold">{exam.average_score.toFixed(1)}%</p>
                      <p className="text-sm text-muted-foreground">Average</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center text-sm text-muted-foreground py-4">
                  No recent exam results available
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Upcoming Exams
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {stats.upcomingExams.length > 0 ? (
                stats.upcomingExams.map((exam, index) => (
                  <div key={index} className="flex justify-between items-start p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">{exam.exam_name}</p>
                      <p className="text-sm text-muted-foreground">{exam.subject_name}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{new Date(exam.exam_date).toLocaleDateString()}</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center text-sm text-muted-foreground py-4">
                  No upcoming exams scheduled
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Fee Status Alert */}
      {stats.pendingFees.students > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="text-orange-800">Fee Collection Alert</CardTitle>
            <CardDescription className="text-orange-700">
              {stats.pendingFees.students} students have unpaid fees, totaling {formatCurrency(stats.pendingFees.amount)}.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-center">
              <p className="text-orange-700">Students with pending fees</p>
              <p className="text-xl font-bold text-orange-800">{stats.pendingFees.students}</p>
            </div>
            <div className="flex justify-between items-center mt-2">
              <p className="text-orange-700">Total pending amount</p>
              <p className="text-xl font-bold text-orange-800">{formatCurrency(stats.pendingFees.amount)}</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default EnhancedDashboard;
