import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { Brain, TrendingUp, AlertCircle, Target, Lightbulb, Users } from 'lucide-react';

const AIInsightsWidget = () => {
  const { data: insights } = useQuery({
    queryKey: ['ai-insights'],
    queryFn: async () => {
      // Gather data for AI analysis
      const [
        studentsResult,
        attendanceResult,
        paymentsResult,
        teachersResult
      ] = await Promise.all([
        supabase.from('students').select('*'),
        supabase.from('attendance').select('*').gte('date', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()),
        supabase.from('payments').select('*').gte('created_at', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()),
        supabase.from('teachers').select('*')
      ]);

      const students = studentsResult.data || [];
      const attendance = attendanceResult.data || [];
      const payments = paymentsResult.data || [];
      const teachers = teachersResult.data || [];

      // Generate AI-powered insights
      const insights = [];

      // Attendance insight
      const attendanceRate = attendance.length > 0 
        ? (attendance.filter(a => a.status === 'present').length / attendance.length) * 100 
        : 0;
      
      if (attendanceRate < 85) {
        insights.push({
          type: 'warning',
          icon: AlertCircle,
          title: 'Low Attendance Alert',
          description: `Attendance rate is ${attendanceRate.toFixed(1)}%. Consider implementing engagement strategies.`,
          action: 'Review attendance patterns'
        });
      } else if (attendanceRate > 95) {
        insights.push({
          type: 'success',
          icon: TrendingUp,
          title: 'Excellent Attendance',
          description: `Outstanding ${attendanceRate.toFixed(1)}% attendance rate! Keep up the great work.`,
          action: 'Maintain current strategies'
        });
      }

      // Payment collection insight
      const totalCollected = payments.reduce((sum, p) => sum + Number(p.amount), 0);
      const avgDailyCollection = totalCollected / 30;
      
      if (avgDailyCollection > 50000) {
        insights.push({
          type: 'success',
          icon: TrendingUp,
          title: 'Strong Revenue Growth',
          description: `Daily average of UGX ${avgDailyCollection.toLocaleString()} shows healthy cash flow.`,
          action: 'Continue current fee collection practices'
        });
      }

      // Class size optimization with proper typing
      const classDistribution: Record<string, number> = students.reduce((acc, student) => {
        const className = student.class || 'Unknown';
        acc[className] = (acc[className] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);
      
      const classSizes = Object.values(classDistribution);
      if (classSizes.length > 0) {
        const maxClassSize = Math.max(...classSizes);
        const minClassSize = Math.min(...classSizes);
        
        if (maxClassSize - minClassSize > 10) {
          insights.push({
            type: 'info',
            icon: Users,
            title: 'Class Size Imbalance',
            description: `Consider redistributing students. Largest class: ${maxClassSize}, smallest: ${minClassSize}.`,
            action: 'Balance class sizes'
          });
        }
      }

      // Teacher-student ratio
      const teacherStudentRatio = students.length / teachers.length;
      if (teacherStudentRatio > 25) {
        insights.push({
          type: 'warning',
          icon: Target,
          title: 'High Teacher-Student Ratio',
          description: `Current ratio is 1:${teacherStudentRatio.toFixed(0)}. Consider hiring more teachers.`,
          action: 'Plan teacher recruitment'
        });
      }

      // Fee collection patterns
      const unpaidStudents = students.filter(s => s.fee_status === 'Unpaid').length;
      const unpaidPercentage = (unpaidStudents / students.length) * 100;
      
      if (unpaidPercentage > 20) {
        insights.push({
          type: 'warning',
          icon: AlertCircle,
          title: 'Fee Collection Concern',
          description: `${unpaidPercentage.toFixed(1)}% of students have unpaid fees. Implement follow-up strategy.`,
          action: 'Send fee reminders'
        });
      }

      // Positive insights for motivation
      insights.push({
        type: 'tip',
        icon: Lightbulb,
        title: 'Smart Recommendation',
        description: 'Schedule monthly parent-teacher meetings to improve student engagement and fee collection.',
        action: 'Schedule meetings'
      });

      return insights.slice(0, 4); // Return top 4 insights
    },
    refetchInterval: 5 * 60 * 1000, // Refresh every 5 minutes
  });

  const getIconColor = (type: string) => {
    switch (type) {
      case 'success': return 'text-green-500';
      case 'warning': return 'text-orange-500';
      case 'info': return 'text-primary';
      case 'tip': return 'text-purple-500';
      default: return 'text-muted-foreground';
    }
  };

  const getBadgeVariant = (type: string): "default" | "secondary" | "destructive" | "outline" => {
    switch (type) {
      case 'success': return 'default';
      case 'warning': return 'destructive';
      case 'info': return 'secondary';
      case 'tip': return 'outline';
      default: return 'secondary';
    }
  };

  return (
    <Card className="animate-fade-in bg-card border-border overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 px-3 sm:px-6">
        <CardTitle className="text-sm sm:text-base font-semibold flex items-center gap-2 text-foreground">
          <Brain className="h-4 w-4 text-purple-500 flex-shrink-0" />
          <span className="truncate">AI Insights</span>
        </CardTitle>
        <Badge variant="outline" className="bg-purple-500/10 text-purple-600 dark:text-purple-400 text-xs hidden sm:inline-flex">
          Smart
        </Badge>
      </CardHeader>
      <CardContent className="space-y-2 px-3 sm:px-6 max-h-[300px] sm:max-h-[350px] overflow-y-auto">
        {insights?.map((insight, index) => {
          const IconComponent = insight.icon;
          return (
            <div 
              key={index} 
              className="p-2 sm:p-3 rounded-lg border border-border bg-secondary/50 hover:bg-accent/50 transition-colors duration-200"
            >
              <div className="flex items-start gap-2">
                <IconComponent className={`h-4 w-4 mt-0.5 flex-shrink-0 ${getIconColor(insight.type)}`} />
                <div className="flex-1 min-w-0 space-y-0.5">
                  <div className="flex items-center justify-between gap-2">
                    <h4 className="text-xs sm:text-sm font-medium text-foreground truncate">{insight.title}</h4>
                    <Badge variant={getBadgeVariant(insight.type)} className="text-[10px] flex-shrink-0">
                      {insight.type.toUpperCase()}
                    </Badge>
                  </div>
                  <p className="text-[10px] sm:text-xs text-muted-foreground leading-relaxed line-clamp-2">
                    {insight.description}
                  </p>
                  <p className="text-[10px] sm:text-xs text-primary font-medium truncate">
                    💡 {insight.action}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
        
        {!insights || insights.length === 0 && (
          <div className="text-center py-4">
            <Brain className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">
              Analyzing school data for insights...
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AIInsightsWidget;
