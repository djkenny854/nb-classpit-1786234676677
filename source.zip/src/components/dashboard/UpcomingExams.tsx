import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, BookOpen } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface ExamData {
  id: string;
  name: string;
  term: string;
  year: string;
  start_date: string;
  end_date: string;
  is_active: boolean;
}

const UpcomingExams = () => {
  const [upcomingExams, setUpcomingExams] = useState<ExamData[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchUpcomingExams();
    
    // Set up real-time subscription
    const channel = supabase
      .channel('exams-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'exams'
        },
        (payload) => {
          console.log('Exams table changed:', payload);
          fetchUpcomingExams();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchUpcomingExams = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];
      
      const { data, error } = await supabase
        .from('exams')
        .select('*')
        .gte('start_date', today)
        .order('start_date', { ascending: true })
        .limit(5);

      if (error) throw error;
      
      setUpcomingExams(data || []);
    } catch (error) {
      console.error('Error fetching upcoming exams:', error);
      toast({
        title: "Error",
        description: "Failed to fetch upcoming exams",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric'
    });
  };

  const getDaysUntilExam = (startDate: string) => {
    const today = new Date();
    const examDate = new Date(startDate);
    const diffTime = examDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const getStatusColor = (daysUntil: number, isActive: boolean) => {
    if (isActive) return 'bg-green-500/20 text-green-700 dark:text-green-400';
    if (daysUntil <= 3) return 'bg-destructive/20 text-destructive';
    if (daysUntil <= 7) return 'bg-yellow-500/20 text-yellow-700 dark:text-yellow-400';
    return 'bg-primary/20 text-primary';
  };

  const getStatusText = (daysUntil: number, isActive: boolean) => {
    if (isActive) return 'Active';
    if (daysUntil === 0) return 'Today';
    if (daysUntil === 1) return 'Tomorrow';
    if (daysUntil < 0) return 'Ongoing';
    return `${daysUntil} days`;
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            Upcoming Exams
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center py-4">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BookOpen className="h-5 w-5" />
          Upcoming Exams
        </CardTitle>
      </CardHeader>
      <CardContent>
        {upcomingExams.length === 0 ? (
          <div className="text-center py-6 text-muted-foreground">
            <Calendar className="h-12 w-12 mx-auto text-muted-foreground/50 mb-2" />
            <p>No upcoming exams scheduled</p>
          </div>
        ) : (
          <div className="space-y-4">
            {upcomingExams.map((exam) => {
              const daysUntil = getDaysUntilExam(exam.start_date);
              return (
                <div key={exam.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                  <div className="flex-1">
                    <h4 className="font-medium text-sm text-foreground">{exam.name}</h4>
                    <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        <span>{formatDate(exam.start_date)}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        <span>{exam.term} {exam.year}</span>
                      </div>
                    </div>
                  </div>
                  <Badge 
                    className={`text-xs ${getStatusColor(daysUntil, exam.is_active)}`}
                  >
                    {getStatusText(daysUntil, exam.is_active)}
                  </Badge>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default UpcomingExams;
