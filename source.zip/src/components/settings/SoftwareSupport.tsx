
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ExternalLink, Bug, Info, LifeBuoy, Shield, Code, Download } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';

const SoftwareSupport = () => {
  const { toast } = useToast();

  const handleDownloadLogs = () => {
    toast({
      title: "Logs downloaded",
      description: "System logs have been downloaded successfully."
    });
  };

  const openExternalLink = (url: string) => {
    // This would normally open in a new tab, but we'll just show a toast for the demo
    toast({
      title: "External link",
      description: `Opening: ${url}`
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Software Info & Support</h2>
        <p className="text-muted-foreground">Get information about your software version and access support resources.</p>
      </div>
      
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Info className="mr-2 h-5 w-5" />
              Software Information
            </CardTitle>
            <CardDescription>Details about your current installation</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between py-2 border-b">
                <span className="font-medium">Version</span>
                <span>SchoolSync v1.0.0</span>
              </div>
              <div className="flex justify-between py-2 border-b">
                <span className="font-medium">License</span>
                <span>Professional Edition</span>
              </div>
              <div className="flex justify-between py-2 border-b">
                <span className="font-medium">Last Updated</span>
                <span>April 16, 2025</span>
              </div>
              <div className="flex justify-between py-2 border-b">
                <span className="font-medium">Build ID</span>
                <span>20250416-01</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="font-medium">Framework</span>
                <span>React 18.3.1</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <LifeBuoy className="mr-2 h-5 w-5" />
              Support Resources
            </CardTitle>
            <CardDescription>Get help with using SchoolSync</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Button variant="outline" className="w-full justify-between" 
                onClick={() => openExternalLink("https://schoolsync.docs/documentation")}>
                Documentation
                <ExternalLink className="h-4 w-4" />
              </Button>
              <Button variant="outline" className="w-full justify-between"
                onClick={() => openExternalLink("https://schoolsync.docs/tutorials")}>
                Video Tutorials
                <ExternalLink className="h-4 w-4" />
              </Button>
              <Button variant="outline" className="w-full justify-between"
                onClick={() => openExternalLink("https://schoolsync.docs/help")}>
                Help Center
                <ExternalLink className="h-4 w-4" />
              </Button>
              <Button variant="outline" className="w-full justify-between"
                onClick={() => openExternalLink("https://schoolsync.community")}>
                Community Forum
                <ExternalLink className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Bug className="mr-2 h-5 w-5" />
              Bug Reporting
            </CardTitle>
            <CardDescription>Report issues or suggest improvements</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Found an issue? Help us improve by reporting bugs or suggesting new features.
            </p>
            <div className="space-y-4">
              <Button variant="outline" className="w-full justify-between"
                onClick={() => openExternalLink("https://schoolsync.docs/bug-report")}>
                Report a Bug
                <ExternalLink className="h-4 w-4" />
              </Button>
              <Button variant="outline" className="w-full justify-between"
                onClick={() => openExternalLink("https://schoolsync.docs/feature-request")}>
                Feature Request
                <ExternalLink className="h-4 w-4" />
              </Button>
              
              <Separator className="my-4" />
              
              <div className="space-y-3">
                <h4 className="font-medium text-sm">System Diagnostics</h4>
                <Button variant="outline" className="w-full justify-between" onClick={handleDownloadLogs}>
                  Download System Logs
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Code className="mr-2 h-5 w-5" />
              Developer Resources
            </CardTitle>
            <CardDescription>Access tools and information for developers</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-3 bg-muted rounded-md">
                <h4 className="font-medium mb-2">Kenny Syntax Solution (KSS)</h4>
                <div className="text-sm text-muted-foreground space-y-1">
                  <p>Version: 1.0.0</p>
                  <p>Engine: React Parser v3.2</p>
                  <p>Status: Active</p>
                </div>
              </div>
              
              <Button variant="outline" className="w-full justify-between"
                onClick={() => openExternalLink("https://schoolsync.docs/api")}>
                API Documentation
                <ExternalLink className="h-4 w-4" />
              </Button>
              
              <Button variant="outline" className="w-full justify-between"
                onClick={() => openExternalLink("https://schoolsync.docs/webhooks")}>
                Webhook Setup
                <ExternalLink className="h-4 w-4" />
              </Button>
              
              <Button variant="outline" className="w-full justify-between"
                onClick={() => openExternalLink("https://github.com/schoolsync/examples")}>
                Code Examples
                <ExternalLink className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Shield className="mr-2 h-5 w-5" />
              Legal Information
            </CardTitle>
            <CardDescription>Terms of use and privacy</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4">
              <Button variant="outline" className="w-full justify-between"
                onClick={() => openExternalLink("https://schoolsync.docs/terms")}>
                Terms of Use
                <ExternalLink className="h-4 w-4" />
              </Button>
              <Button variant="outline" className="w-full justify-between"
                onClick={() => openExternalLink("https://schoolsync.docs/privacy")}>
                Privacy Policy
                <ExternalLink className="h-4 w-4" />
              </Button>
              <Button variant="outline" className="w-full justify-between"
                onClick={() => openExternalLink("https://schoolsync.docs/dpa")}>
                Data Processing Agreement
                <ExternalLink className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SoftwareSupport;
