
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Shield, Lock, Key, AlertTriangle, Eye, Save, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const SecuritySettings = () => {
  const [passwordPolicy, setPasswordPolicy] = useState('strong');
  const [sessionTimeout, setSessionTimeout] = useState('60');
  const [twoFactorAuth, setTwoFactorAuth] = useState(false);
  const [loginAttempts, setLoginAttempts] = useState('5');
  const [lockoutDuration, setLockoutDuration] = useState('15');
  const [auditLogging, setAuditLogging] = useState(true);
  const { toast } = useToast();

  const mockSecurityLogs = [
    { id: 1, event: 'Failed login attempt', user: 'admin@school.edu', ip: '192.168.1.100', time: '2024-01-26 09:15', severity: 'medium' },
    { id: 2, event: 'Password changed', user: 'teacher@school.edu', ip: '192.168.1.102', time: '2024-01-26 08:30', severity: 'low' },
    { id: 3, event: 'Multiple login failures', user: 'unknown', ip: '10.0.0.50', time: '2024-01-26 07:45', severity: 'high' },
  ];

  const handleSave = () => {
    toast({
      title: "Settings saved",
      description: "Security settings have been updated successfully."
    });
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high':
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      case 'medium':
        return <Eye className="h-4 w-4 text-yellow-600" />;
      case 'low':
        return <Shield className="h-4 w-4 text-green-600" />;
      default:
        return <Shield className="h-4 w-4 text-gray-600" />;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Security Settings</h2>
        <p className="text-muted-foreground">Configure security policies and access controls.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Lock className="mr-2 h-5 w-5" />
              Password Policy
            </CardTitle>
            <CardDescription>Configure password requirements</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Password Strength</Label>
              <Select value={passwordPolicy || 'strong'} onValueChange={setPasswordPolicy}>
                <SelectTrigger>
                  <SelectValue placeholder="Select policy" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="basic">Basic (6+ characters)</SelectItem>
                  <SelectItem value="moderate">Moderate (8+ chars, mixed case)</SelectItem>
                  <SelectItem value="strong">Strong (12+ chars, mixed case, numbers, symbols)</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Password Expiry (Days)</Label>
              <Input type="number" placeholder="90" />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Force Password Change</Label>
                <p className="text-xs text-muted-foreground">
                  Require password change on first login
                </p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Prevent Password Reuse</Label>
                <p className="text-xs text-muted-foreground">
                  Remember last 5 passwords
                </p>
              </div>
              <Switch defaultChecked />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Key className="mr-2 h-5 w-5" />
              Authentication
            </CardTitle>
            <CardDescription>Configure login and session settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Session Timeout (Minutes)</Label>
              <Select value={sessionTimeout || '60'} onValueChange={setSessionTimeout}>
                <SelectTrigger>
                  <SelectValue placeholder="Select timeout" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="15">15 Minutes</SelectItem>
                  <SelectItem value="30">30 Minutes</SelectItem>
                  <SelectItem value="60">1 Hour</SelectItem>
                  <SelectItem value="120">2 Hours</SelectItem>
                  <SelectItem value="480">8 Hours</SelectItem>
                  <SelectItem value="never">Never</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Two-Factor Authentication</Label>
                <p className="text-xs text-muted-foreground">
                  Require 2FA for all users
                </p>
              </div>
              <Switch checked={twoFactorAuth} onCheckedChange={setTwoFactorAuth} />
            </div>

            <div className="space-y-2">
              <Label>Max Login Attempts</Label>
              <Select value={loginAttempts || '5'} onValueChange={setLoginAttempts}>
                <SelectTrigger>
                  <SelectValue placeholder="Select attempts" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3">3 Attempts</SelectItem>
                  <SelectItem value="5">5 Attempts</SelectItem>
                  <SelectItem value="10">10 Attempts</SelectItem>
                  <SelectItem value="unlimited">Unlimited</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Account Lockout Duration (Minutes)</Label>
              <Select value={lockoutDuration || '15'} onValueChange={setLockoutDuration}>
                <SelectTrigger>
                  <SelectValue placeholder="Select duration" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">5 Minutes</SelectItem>
                  <SelectItem value="15">15 Minutes</SelectItem>
                  <SelectItem value="30">30 Minutes</SelectItem>
                  <SelectItem value="60">1 Hour</SelectItem>
                  <SelectItem value="1440">24 Hours</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Shield className="mr-2 h-5 w-5" />
              System Security
            </CardTitle>
            <CardDescription>Configure system-wide security settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Enable Audit Logging</Label>
                <p className="text-xs text-muted-foreground">
                  Log all user actions and system events
                </p>
              </div>
              <Switch checked={auditLogging} onCheckedChange={setAuditLogging} />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>IP Whitelist</Label>
                <p className="text-xs text-muted-foreground">
                  Restrict access to specific IP addresses
                </p>
              </div>
              <Switch />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>SSL/TLS Enforcement</Label>
                <p className="text-xs text-muted-foreground">
                  Force HTTPS connections
                </p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Security Headers</Label>
                <p className="text-xs text-muted-foreground">
                  Enable security-related HTTP headers
                </p>
              </div>
              <Switch defaultChecked />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Clock className="mr-2 h-5 w-5" />
              Recent Security Events
            </CardTitle>
            <CardDescription>Monitor security-related activities</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {mockSecurityLogs.map((log) => (
                <div key={log.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    {getSeverityIcon(log.severity)}
                    <div>
                      <p className="font-medium text-sm">{log.event}</p>
                      <p className="text-xs text-muted-foreground">
                        {log.user} from {log.ip}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">{log.time}</p>
                    <Badge className={getSeverityColor(log.severity)}>
                      {log.severity}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
            <Button variant="outline" className="w-full mt-4">
              View All Security Logs
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end pt-4">
        <Button onClick={handleSave} className="min-w-32">
          <Save className="h-4 w-4 mr-2" />
          Save Settings
        </Button>
      </div>
    </div>
  );
};

export default SecuritySettings;
