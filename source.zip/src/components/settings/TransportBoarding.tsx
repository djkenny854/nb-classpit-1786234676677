import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useMobile } from '@/hooks/use-mobile';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Bus, Home, Plus, Edit2, Trash2, Loader2 } from 'lucide-react';
import { useTransportSettings } from '@/hooks/useTransportSettings';

const TransportBoarding = () => {
  const { vehicles, routes, facilities, loading, addVehicle, addRoute, addFacility } = useTransportSettings();
  const isMobile = useMobile();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState<'vehicle' | 'route' | 'facility'>('vehicle');
  const [formData, setFormData] = useState<any>({});

  const handleAddNew = (type: 'vehicle' | 'route' | 'facility') => {
    setDialogType(type);
    setFormData({});
    setDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (dialogType === 'vehicle') {
        await addVehicle({
          vehicle_number: formData.vehicle_number,
          driver_name: formData.driver_name,
          driver_phone: formData.driver_phone,
          route_name: formData.route_name,
          capacity: parseInt(formData.capacity || '0'),
          status: formData.status || 'active',
          maintenance_schedule: {}
        });
      } else if (dialogType === 'route') {
        await addRoute({
          route_name: formData.route_name,
          stops: formData.stops?.split(',').map((s: string) => s.trim()) || [],
          vehicle_id: formData.vehicle_id,
          schedule: {},
          fee_amount: parseFloat(formData.fee_amount || '0')
        });
      } else if (dialogType === 'facility') {
        await addFacility({
          facility_name: formData.facility_name,
          facility_type: formData.facility_type,
          capacity: parseInt(formData.capacity || '0'),
          supervisor_name: formData.supervisor_name,
          supervisor_phone: formData.supervisor_phone,
          rules: {},
          fee_amount: parseFloat(formData.fee_amount || '0')
        });
      }
      
      setDialogOpen(false);
      setFormData({});
    } catch (error) {
      // Error handling is done in the hooks
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin" />
        <span className="ml-2">Loading transport & boarding settings...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Transport & Boarding</h2>
        <p className="text-muted-foreground">Manage vehicles, routes, and boarding facilities.</p>
      </div>

      <Tabs defaultValue="transport" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="transport">
            <Bus className="h-4 w-4" />
            {!isMobile && <span className="ml-2">Transport Management</span>}
          </TabsTrigger>
          <TabsTrigger value="boarding">
            <Home className="h-4 w-4" />
            {!isMobile && <span className="ml-2">Boarding Facilities</span>}
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="transport" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Bus className="h-5 w-5" />
                      Transport Vehicles
                    </CardTitle>
                    <CardDescription>Manage school vehicles and drivers</CardDescription>
                  </div>
                  <Button onClick={() => handleAddNew('vehicle')} size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Vehicle
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {vehicles.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Bus className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>No vehicles registered</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {vehicles.map((vehicle) => (
                      <div key={vehicle.id} className="flex items-center justify-between p-2 border rounded">
                        <div>
                          <p className="font-medium">{vehicle.vehicle_number}</p>
                          <p className="text-sm text-muted-foreground">{vehicle.driver_name}</p>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="icon">
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Transport Routes</CardTitle>
                    <CardDescription>Manage transport routes and schedules</CardDescription>
                  </div>
                  <Button onClick={() => handleAddNew('route')} size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Route
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {routes.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <p>No routes configured</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {routes.map((route) => (
                      <div key={route.id} className="flex items-center justify-between p-2 border rounded">
                        <div>
                          <p className="font-medium">{route.route_name}</p>
                          <p className="text-sm text-muted-foreground">
                            {route.stops.length} stops • UGX {route.fee_amount?.toLocaleString() || 0}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="icon">
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="boarding" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Home className="h-5 w-5" />
                    Boarding Facilities
                  </CardTitle>
                  <CardDescription>Manage dormitories and boarding facilities</CardDescription>
                </div>
                <Button onClick={() => handleAddNew('facility')} size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Facility
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {facilities.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Home className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>No boarding facilities registered</p>
                </div>
              ) : (
                <div className="grid gap-4 md:grid-cols-2">
                  {facilities.map((facility) => (
                    <div key={facility.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">{facility.facility_name}</h4>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="icon">
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">
                        Type: {facility.facility_type}
                      </p>
                      <p className="text-sm text-muted-foreground mb-1">
                        Capacity: {facility.capacity} students
                      </p>
                      <p className="text-sm text-muted-foreground mb-1">
                        Supervisor: {facility.supervisor_name}
                      </p>
                      <p className="text-sm font-medium">
                        Fee: UGX {facility.fee_amount?.toLocaleString() || 0}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              Add New {dialogType === 'vehicle' ? 'Vehicle' : dialogType === 'route' ? 'Route' : 'Facility'}
            </DialogTitle>
            <DialogDescription>
              Enter the details for the new {dialogType}.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              {dialogType === 'vehicle' && (
                <>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right text-sm font-medium">Vehicle Number</label>
                    <Input
                      className="col-span-3"
                      value={formData.vehicle_number || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, vehicle_number: e.target.value }))}
                      required
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right text-sm font-medium">Driver Name</label>
                    <Input
                      className="col-span-3"
                      value={formData.driver_name || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, driver_name: e.target.value }))}
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right text-sm font-medium">Driver Phone</label>
                    <Input
                      className="col-span-3"
                      value={formData.driver_phone || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, driver_phone: e.target.value }))}
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right text-sm font-medium">Capacity</label>
                    <Input
                      type="number"
                      className="col-span-3"
                      value={formData.capacity || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, capacity: e.target.value }))}
                    />
                  </div>
                </>
              )}

              {dialogType === 'route' && (
                <>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right text-sm font-medium">Route Name</label>
                    <Input
                      className="col-span-3"
                      value={formData.route_name || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, route_name: e.target.value }))}
                      required
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right text-sm font-medium">Stops</label>
                    <Input
                      className="col-span-3"
                      placeholder="Stop 1, Stop 2, Stop 3"
                      value={formData.stops || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, stops: e.target.value }))}
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right text-sm font-medium">Fee Amount</label>
                    <Input
                      type="number"
                      className="col-span-3"
                      value={formData.fee_amount || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, fee_amount: e.target.value }))}
                    />
                  </div>
                </>
              )}

              {dialogType === 'facility' && (
                <>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right text-sm font-medium">Facility Name</label>
                    <Input
                      className="col-span-3"
                      value={formData.facility_name || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, facility_name: e.target.value }))}
                      required
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right text-sm font-medium">Facility Type</label>
                    <Select
                      value={formData.facility_type || ''}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, facility_type: value }))}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="dormitory">Dormitory</SelectItem>
                        <SelectItem value="dining_hall">Dining Hall</SelectItem>
                        <SelectItem value="study_hall">Study Hall</SelectItem>
                        <SelectItem value="recreation">Recreation Area</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right text-sm font-medium">Capacity</label>
                    <Input
                      type="number"
                      className="col-span-3"
                      value={formData.capacity || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, capacity: e.target.value }))}
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right text-sm font-medium">Supervisor</label>
                    <Input
                      className="col-span-3"
                      value={formData.supervisor_name || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, supervisor_name: e.target.value }))}
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label className="text-right text-sm font-medium">Fee Amount</label>
                    <Input
                      type="number"
                      className="col-span-3"
                      value={formData.fee_amount || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, fee_amount: e.target.value }))}
                    />
                  </div>
                </>
              )}
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit">Add {dialogType === 'vehicle' ? 'Vehicle' : dialogType === 'route' ? 'Route' : 'Facility'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default TransportBoarding;
