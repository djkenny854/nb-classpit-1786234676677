
import React from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  MousePointer2,
  Settings2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
  DropdownMenuItem,
} from '@/components/ui/dropdown-menu';
import { useSiteSettings } from '@/context/SiteSettingsContext';

const SidebarControls = () => {
  const { isSidebarOpen, toggleSidebar, sidebarMode, setSidebarMode } = useSiteSettings();

  const handleModeChange = (mode: 'normal' | 'hover') => {
    setSidebarMode(mode);
    if (mode === 'hover' && isSidebarOpen) {
      // If switching to hover mode and sidebar is open, collapse it
      toggleSidebar();
    }
  };

  return (
    <div className="p-2 flex items-center justify-between">
      {/* Expand/Collapse Toggle */}
      <Button
        onClick={toggleSidebar}
        variant="ghost"
        size="sm"
        className={`p-2 h-8 w-8 transition-all duration-300 ${
          !isSidebarOpen ? 'group-hover:opacity-100' : ''
        }`}
      >
        {isSidebarOpen ? (
          <ChevronLeft className="h-4 w-4" />
        ) : (
          <ChevronRight className="h-4 w-4" />
        )}
      </Button>

      {/* Mode Selector */}
      <div className={`transition-all duration-300 ${
        !isSidebarOpen 
          ? 'opacity-0 w-0 overflow-hidden group-hover:opacity-100 group-hover:w-auto' 
          : 'opacity-100'
      }`}>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="p-2 h-8 w-8">
              <Settings2 className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" side="top">
            <DropdownMenuItem 
              onClick={() => handleModeChange('normal')}
              className={sidebarMode === 'normal' ? 'bg-accent' : ''}
            >
              <div className="flex items-center gap-2">
                <ChevronRight className="h-4 w-4" />
                <span>Normal Mode</span>
              </div>
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={() => handleModeChange('hover')}
              className={sidebarMode === 'hover' ? 'bg-accent' : ''}
            >
              <div className="flex items-center gap-2">
                <MousePointer2 className="h-4 w-4" />
                <span>Hover Mode</span>
              </div>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
};

export default SidebarControls;
