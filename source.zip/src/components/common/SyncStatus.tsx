
import React from 'react';
import { AlertCircle, CheckCircle, Loader2, WifiOff } from 'lucide-react';
import { SyncStatus as SyncStatusType } from '@/types';
import { cn } from '@/lib/utils';

interface SyncStatusProps {
  status: SyncStatusType;
}

const SyncStatus: React.FC<SyncStatusProps> = ({ status }) => {
  const { status: syncStatus, lastSyncedAt, syncedWithDevices, pendingChanges } = status;

  const getStatusDetails = () => {
    switch (syncStatus) {
      case 'synced':
        return {
          icon: <CheckCircle className="h-4 w-4 text-green-500" />,
          text: 'Synced',
          className: 'text-green-500',
          description: lastSyncedAt ? `Last synced ${new Date(lastSyncedAt).toLocaleTimeString()}` : 'All changes saved'
        };
      case 'syncing':
        return {
          icon: <Loader2 className="h-4 w-4 text-blue-500 animate-spin" />,
          text: 'Syncing',
          className: 'text-blue-500',
          description: `Syncing with ${syncedWithDevices.length} device(s)`
        };
      case 'offline':
        return {
          icon: <WifiOff className="h-4 w-4 text-amber-500" />,
          text: 'Offline',
          className: 'text-amber-500',
          description: pendingChanges > 0 ? `${pendingChanges} changes pending sync` : 'Working offline'
        };
      case 'error':
        return {
          icon: <AlertCircle className="h-4 w-4 text-red-500" />,
          text: 'Sync Error',
          className: 'text-red-500',
          description: 'Please check your connection'
        };
      default:
        return {
          icon: <WifiOff className="h-4 w-4 text-gray-500" />,
          text: 'Unknown',
          className: 'text-gray-500',
          description: 'Status unknown'
        };
    }
  };

  const details = getStatusDetails();

  return (
    <div className="flex items-center gap-2">
      {details.icon}
      <div>
        <p className={cn("text-xs font-medium", details.className)}>
          {details.text}
        </p>
        <p className="text-xs text-muted-foreground">
          {details.description}
        </p>
      </div>
    </div>
  );
};

export default SyncStatus;
