import { supabase } from '@/lib/supabase';
import { ExamType, ExamResult, SubjectResult, GradeScale, PerformanceStats } from '@/types/exam';
import { v4 as uuidv4 } from 'uuid';

export const createExam = async (examData: Omit<ExamType, 'id'>): Promise<ExamType> => {
  const exam: ExamType = {
    id: uuidv4(),
    ...examData
  };

  const { data, error } = await supabase
    .from('exams')
    .insert(exam)
    .select()
    .single();

  if (error) {
    console.error('Error creating exam:', error);
    throw error;
  }

  return data as ExamType;
};

export const getExams = async (): Promise<ExamType[]> => {
  const { data, error } = await supabase
    .from('exams')
    .select('*')
    .order('startDate', { ascending: false });

  if (error) {
    console.error('Error fetching exams:', error);
    throw error;
  }

  return data as ExamType[];
};

export const getExamById = async (examId: string): Promise<ExamType> => {
  const { data, error } = await supabase
    .from('exams')
    .select('*')
    .eq('id', examId)
    .single();

  if (error) {
    console.error('Error fetching exam:', error);
    throw error;
  }

  return data as ExamType;
};

export const updateExam = async (examId: string, examData: Partial<ExamType>): Promise<ExamType> => {
  const { data, error } = await supabase
    .from('exams')
    .update(examData)
    .eq('id', examId)
    .select()
    .single();

  if (error) {
    console.error('Error updating exam:', error);
    throw error;
  }

  return data as ExamType;
};

export const deleteExam = async (examId: string): Promise<void> => {
  const { error } = await supabase
    .from('exams')
    .delete()
    .eq('id', examId);

  if (error) {
    console.error('Error deleting exam:', error);
    throw error;
  }
};

export const saveExamResults = async (results: Omit<ExamResult, 'id'>): Promise<ExamResult> => {
  const examResult: ExamResult = {
    id: uuidv4(),
    ...results,
    dateEntered: new Date().toISOString()
  };

  const { data, error } = await supabase
    .from('exam_results')
    .insert(examResult)
    .select()
    .single();

  if (error) {
    console.error('Error saving exam results:', error);
    throw error;
  }

  return data as ExamResult;
};

export const getStudentResults = async (studentId: string): Promise<ExamResult[]> => {
  const { data, error } = await supabase
    .from('exam_results')
    .select('*')
    .eq('studentId', studentId)
    .order('dateEntered', { ascending: false });

  if (error) {
    console.error('Error fetching student results:', error);
    throw error;
  }

  return data as ExamResult[];
};

export const getExamResults = async (examId: string): Promise<ExamResult[]> => {
  const { data, error } = await supabase
    .from('exam_results')
    .select('*')
    .eq('exam_id', examId)
    .order('total_marks', { ascending: false });

  if (error) {
    console.error('Error fetching exam results:', error);
    throw error;
  }

  return data as ExamResult[];
};

export const calculateGrade = (percentage: number, gradeScale: GradeScale): string => {
  if (percentage >= gradeScale.A.min) return 'A';
  if (percentage >= gradeScale.B.min) return 'B';
  if (percentage >= gradeScale.C.min) return 'C';
  if (percentage >= gradeScale.D.min) return 'D';
  return 'F';
};

export const calculateClassRanking = (results: ExamResult[]): ExamResult[] => {
  // Sort by totalMarks in descending order
  const sortedResults = [...results].sort((a, b) => b.totalMarks - a.totalMarks);
  
  // Assign position
  return sortedResults.map((result, index) => ({
    ...result,
    position: index + 1
  }));
};

export const generateReportCard = async (studentId: string, examId: string): Promise<string> => {
  // In a real implementation, this would generate a PDF or printable report
  // For now, we'll just return a placeholder
  return `Report card generated for student ${studentId} exam ${examId}`;
};

export const getExamPerformanceStats = async (examId: string): Promise<PerformanceStats> => {
  const results = await getExamResults(examId);

  if (results.length === 0) {
    return {
      totalStudents: 0,
      highestScore: 0,
      lowestScore: 0,
      averageScore: 0,
      passRate: 0,
      gradeDistribution: { A: 0, B: 0, C: 0, D: 0, F: 0 },
    };
  }

  const totalStudents = results.length;
  const scores = results.map(r => r.averageMarks);
  const highestScore = Math.max(...scores);
  const lowestScore = Math.min(...scores);
  const averageScore = scores.reduce((sum, score) => sum + score, 0) / totalStudents;
  
  const passCount = results.filter(r => r.grade !== 'F').length;
  const passRate = (passCount / totalStudents) * 100;

  const gradeDistribution = results.reduce((dist, r) => {
    const grade = r.grade as keyof PerformanceStats['gradeDistribution'];
    if (dist.hasOwnProperty(grade)) {
      dist[grade]++;
    }
    return dist;
  }, { A: 0, B: 0, C: 0, D: 0, F: 0 });

  return {
    totalStudents,
    highestScore,
    lowestScore,
    averageScore,
    passRate,
    gradeDistribution,
  };
};
