
import { AttendanceSettingsData } from '@/types/attendance';

const DEFAULT_SETTINGS: AttendanceSettingsData = {
  attendancePeriod: 'daily',
  allowFutureAttendance: false,
  lockAfterHours: 24,
  absentThreshold: 3,
  notifyParentsOnAbsence: true,
  requireAbsenceExplanation: true,
  monthlyReport: 'class-teacher',
  enableDisciplineTracking: true,
  escalationLevels: 3,
  notifyParentsForDisciplinary: true,
  requireAdminApproval: true,
  defaultAction: 'warning',
  allowCustomTypes: false
};

export const getAttendanceSettings = (): AttendanceSettingsData => {
  try {
    // First try to get from window
    if (window.attendanceSettings) {
      return window.attendanceSettings;
    }
    
    // Then try localStorage
    const savedSettings = localStorage.getItem('attendanceSettings');
    if (savedSettings) {
      const parsed = JSON.parse(savedSettings);
      window.attendanceSettings = { ...DEFAULT_SETTINGS, ...parsed };
      return window.attendanceSettings;
    }
    
    // Return defaults
    window.attendanceSettings = DEFAULT_SETTINGS;
    return DEFAULT_SETTINGS;
  } catch (error) {
    console.error('Error loading attendance settings:', error);
    return DEFAULT_SETTINGS;
  }
};

export const saveAttendanceSettings = (settings: AttendanceSettingsData): void => {
  try {
    localStorage.setItem('attendanceSettings', JSON.stringify(settings));
    window.attendanceSettings = settings;
  } catch (error) {
    console.error('Error saving attendance settings:', error);
    throw error;
  }
};
