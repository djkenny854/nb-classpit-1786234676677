import { supabase } from '@/integrations/supabase/client';
import type { 
  Assessment, 
  AssessmentGrade, 
  AssessmentCategory, 
  StudentAssessmentSummary,
  GradingStats,
  AssessmentType
} from '@/types/grading';

// Assessment Categories
export const getAssessmentCategories = async (): Promise<AssessmentCategory[]> => {
  const { data, error } = await supabase
    .from('assessment_categories')
    .select('*')
    .eq('is_active', true)
    .order('name');
  
  if (error) throw error;
  return data || [];
};

export const createAssessmentCategory = async (category: Omit<AssessmentCategory, 'id' | 'created_at' | 'updated_at'>): Promise<AssessmentCategory> => {
  const { data, error } = await supabase
    .from('assessment_categories')
    .insert(category)
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

// Assessments
export const getAssessments = async (filters?: {
  class_name?: string;
  subject_id?: string;
  assessment_type?: AssessmentType;
  academic_year?: string;
  academic_term?: string;
}): Promise<Assessment[]> => {
  let query = supabase
    .from('assessments')
    .select(`
      *,
      enhanced_subjects!inner(name),
      assessment_categories(name, description, weight)
    `)
    .order('assessment_date', { ascending: false });

  if (filters?.class_name) {
    query = query.eq('class_name', filters.class_name);
  }
  if (filters?.subject_id) {
    query = query.eq('subject_id', filters.subject_id);
  }
  if (filters?.assessment_type) {
    query = query.eq('assessment_type', filters.assessment_type);
  }
  if (filters?.academic_year) {
    query = query.eq('academic_year', filters.academic_year);
  }
  if (filters?.academic_term) {
    query = query.eq('academic_term', filters.academic_term);
  }

  const { data, error } = await query;
  
  if (error) throw error;
  
  return (data || []).map(item => ({
    ...item,
    subject_name: item.enhanced_subjects?.name,
    category: item.assessment_categories as AssessmentCategory | undefined
  }));
};

export const createAssessment = async (assessment: Omit<Assessment, 'id' | 'created_at' | 'updated_at'>): Promise<Assessment> => {
  const { data, error } = await supabase
    .from('assessments')
    .insert(assessment)
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

export const updateAssessment = async (id: string, updates: Partial<Assessment>): Promise<Assessment> => {
  const { data, error } = await supabase
    .from('assessments')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

export const deleteAssessment = async (id: string): Promise<void> => {
  const { error } = await supabase
    .from('assessments')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
};

// Assessment Grades
export const getAssessmentGrades = async (assessment_id: string): Promise<AssessmentGrade[]> => {
  const { data, error } = await supabase
    .from('assessment_grades')
    .select(`
      *,
      students!inner(full_name),
      assessments!inner(title, enhanced_subjects(name))
    `)
    .eq('assessment_id', assessment_id)
    .order('percentage', { ascending: false });
  
  if (error) throw error;
  
  return (data || []).map(item => ({
    ...item,
    student_name: item.students?.full_name,
    assessment_title: item.assessments?.title,
    subject_name: item.assessments?.enhanced_subjects?.name
  }));
};

export const getStudentGrades = async (student_id: string, filters?: {
  subject_id?: string;
  academic_year?: string;
  academic_term?: string;
}): Promise<AssessmentGrade[]> => {
  let query = supabase
    .from('assessment_grades')
    .select(`
      *,
      assessments!inner(title, subject_id, assessment_type, academic_year, academic_term, enhanced_subjects(name))
    `)
    .eq('student_id', student_id)
    .order('graded_at', { ascending: false });

  if (filters?.subject_id) {
    query = query.eq('assessments.subject_id', filters.subject_id);
  }
  if (filters?.academic_year) {
    query = query.eq('assessments.academic_year', filters.academic_year);
  }
  if (filters?.academic_term) {
    query = query.eq('assessments.academic_term', filters.academic_term);
  }

  const { data, error } = await query;
  
  if (error) throw error;
  
  return (data || []).map(item => ({
    ...item,
    assessment_title: item.assessments?.title,
    subject_name: item.assessments?.enhanced_subjects?.name
  }));
};

export const saveGrades = async (grades: Omit<AssessmentGrade, 'id' | 'created_at' | 'updated_at' | 'percentage' | 'grade'>[]): Promise<AssessmentGrade[]> => {
  const { data, error } = await supabase
    .from('assessment_grades')
    .upsert(grades, { onConflict: 'assessment_id,student_id' })
    .select();
  
  if (error) throw error;
  return data || [];
};

export const updateGrade = async (id: string, updates: Partial<AssessmentGrade>): Promise<AssessmentGrade> => {
  const { data, error } = await supabase
    .from('assessment_grades')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

// Student Assessment Summary
export const getStudentAssessmentSummary = async (filters?: {
  student_id?: string;
  class_name?: string;
  subject_id?: string;
  academic_year?: string;
  academic_term?: string;
}): Promise<StudentAssessmentSummary[]> => {
  let query = supabase
    .from('student_assessment_summary')
    .select(`
      *,
      students!inner(full_name),
      enhanced_subjects!inner(name)
    `)
    .order('average_percentage', { ascending: false });

  if (filters?.student_id) {
    query = query.eq('student_id', filters.student_id);
  }
  if (filters?.class_name) {
    query = query.eq('class_name', filters.class_name);
  }
  if (filters?.subject_id) {
    query = query.eq('subject_id', filters.subject_id);
  }
  if (filters?.academic_year) {
    query = query.eq('academic_year', filters.academic_year);
  }
  if (filters?.academic_term) {
    query = query.eq('academic_term', filters.academic_term);
  }

  const { data, error } = await query;
  
  if (error) throw error;
  
  return (data || []).map(item => ({
    ...item,
    student_name: item.students?.full_name,
    subject_name: item.enhanced_subjects?.name
  }));
};

// Analytics and Statistics
export const getGradingStats = async (filters?: {
  class_name?: string;
  subject_id?: string;
  academic_year?: string;
  academic_term?: string;
}): Promise<GradingStats> => {
  // Get assessment counts
  let assessmentQuery = supabase
    .from('assessments')
    .select('id, is_published');

  if (filters?.class_name) {
    assessmentQuery = assessmentQuery.eq('class_name', filters.class_name);
  }
  if (filters?.subject_id) {
    assessmentQuery = assessmentQuery.eq('subject_id', filters.subject_id);
  }
  if (filters?.academic_year) {
    assessmentQuery = assessmentQuery.eq('academic_year', filters.academic_year);
  }
  if (filters?.academic_term) {
    assessmentQuery = assessmentQuery.eq('academic_term', filters.academic_term);
  }

  const { data: assessments, error: assessmentError } = await assessmentQuery;
  if (assessmentError) throw assessmentError;

  // Get grade statistics
  let gradeQuery = supabase
    .from('assessment_grades')
    .select(`
      percentage,
      grade,
      assessments!inner(class_name, subject_id, academic_year, academic_term)
    `);

  if (filters?.class_name) {
    gradeQuery = gradeQuery.eq('assessments.class_name', filters.class_name);
  }
  if (filters?.subject_id) {
    gradeQuery = gradeQuery.eq('assessments.subject_id', filters.subject_id);
  }
  if (filters?.academic_year) {
    gradeQuery = gradeQuery.eq('assessments.academic_year', filters.academic_year);
  }
  if (filters?.academic_term) {
    gradeQuery = gradeQuery.eq('assessments.academic_term', filters.academic_term);
  }

  const { data: grades, error: gradeError } = await gradeQuery;
  if (gradeError) throw gradeError;

  const totalAssessments = assessments?.length || 0;
  const publishedAssessments = assessments?.filter(a => a.is_published).length || 0;
  const gradedAssessments = grades?.length || 0;
  const pendingAssessments = publishedAssessments - gradedAssessments;

  const averageScore = grades?.length ? 
    grades.reduce((sum, g) => sum + g.percentage, 0) / grades.length : 0;

  const gradeDistribution = {
    A: grades?.filter(g => g.grade === 'A').length || 0,
    B: grades?.filter(g => g.grade === 'B').length || 0,
    C: grades?.filter(g => g.grade === 'C').length || 0,
    D: grades?.filter(g => g.grade === 'D').length || 0,
    F: grades?.filter(g => g.grade === 'F').length || 0,
  };

  return {
    totalAssessments,
    gradedAssessments,
    pendingAssessments,
    averageScore,
    gradeDistribution
  };
};

export const calculateGrade = (percentage: number): string => {
  if (percentage >= 80) return 'A';
  if (percentage >= 70) return 'B';
  if (percentage >= 60) return 'C';
  if (percentage >= 50) return 'D';
  return 'F';
};