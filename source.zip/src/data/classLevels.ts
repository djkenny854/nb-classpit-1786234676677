
// Class levels from nursery to primary 7
export type ClassLevel = {
  id: string;
  name: string;
  displayName: string; // For UI display
  level: number; // For sorting
};

// Define class structure from Nursery to Primary 7
export const CLASS_LEVELS: ClassLevel[] = [
  { id: 'baby', name: 'Baby', displayName: 'Baby Class', level: 0 },
  { id: 'middle', name: 'Middle', displayName: 'Middle Class', level: 1 },
  { id: 'top', name: 'Top', displayName: 'Top Class', level: 2 },
  { id: 'p1', name: 'P1', displayName: 'Primary 1', level: 3 },
  { id: 'p2', name: 'P2', displayName: 'Primary 2', level: 4 },
  { id: 'p3', name: 'P3', displayName: 'Primary 3', level: 5 },
  { id: 'p4', name: 'P4', displayName: 'Primary 4', level: 6 },
  { id: 'p5', name: 'P5', displayName: 'Primary 5', level: 7 },
  { id: 'p6', name: 'P6', displayName: 'Primary 6', level: 8 },
  { id: 'p7', name: 'P7', displayName: 'Primary 7', level: 9 },
];
