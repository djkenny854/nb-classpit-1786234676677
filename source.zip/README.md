
# SchoolSync Assistant

A comprehensive school management system built with TypeScript and React that helps schools manage everything from students to teachers, classes, timetables, exams, and more. This desktop application is designed to run locally on teachers' laptops while providing synchronization capabilities across multiple devices.

## Features

### Core Modules

- **Student Management**: Track student information, enrollments, and academic progress
- **Teacher Management**: Manage teaching staff details, subjects, and responsibilities
- **Classes & Subjects**: Organize educational structure with proper class and subject mapping
- **Timetable System**: Create and manage class schedules and teacher assignments
- **Attendance Tracking**: Record and analyze student attendance patterns
- **Examination & Grading**: Manage exams, record marks, and generate report cards
- **Fee Management**: Track fee payments, dues, and generate reports
- **Library Management**: Catalog books and manage lending/returning
- **School Property Inventory**: Track school assets and equipment
- **Dashboard & Reports**: Get insights with visual data representations

### Technical Features

- **Local-First Database**: Uses SQLite for fast, local data storage
- **Peer Synchronization**: Share data between teacher devices on the same network
- **Offline Mode**: Work without internet connection
- **Role-Based Access**: Different permissions for admin, teachers, and staff
- **Data Export/Import**: Backup and restore functionality
- **Secure Authentication**: Protect sensitive school data

## Technology Stack

- **Frontend**: React with TypeScript
- **UI Framework**: TailwindCSS with shadcn/ui components
- **State Management**: React Context API
- **Database**: SQLite (local storage)
- **Peer Communication**: Socket.io/PeerJS (for device syncing)
- **Build System**: Vite

## Getting Started

### Prerequisites

- Node.js and npm installed
- Basic knowledge of TypeScript and React

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/school-sync-assistant.git
cd school-sync-assistant
```

2. Install dependencies
```bash
npm install
```

3. Start the development server
```bash
npm run dev
```

### Demo Login

- Email: teacher@school.com
- Password: password

## Project Structure

- `/src`
  - `/components` - Reusable UI components
  - `/context` - React context providers
  - `/pages` - Main application pages
  - `/types` - TypeScript type definitions
  - `/utils` - Helper functions and utilities
  - `/database` - Database schema and operations

## Roadmap

- [ ] Complete student management system
- [ ] Implement teacher management features
- [ ] Develop timetable generator
- [ ] Add examination and report card system
- [ ] Create fee management module
- [ ] Implement attendance tracking
- [ ] Develop library management
- [ ] Add school property inventory
- [ ] Implement device synchronization
- [ ] Add data export/import functionality
- [ ] Develop comprehensive reporting

## License

This project is licensed under the MIT License - see the LICENSE file for details.
