
-- Create seat_layouts table to store classroom layout configurations
CREATE TABLE public.seat_layouts (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  class_name text NOT NULL,
  rows integer NOT NULL DEFAULT 6,
  columns integer NOT NULL DEFAULT 10,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(class_name)
);

-- Create seat_assignments table to store which student sits where
CREATE TABLE public.seat_assignments (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  seat_layout_id uuid REFERENCES public.seat_layouts(id) ON DELETE CASCADE,
  seat_position text NOT NULL, -- e.g., "A1", "B5", etc.
  student_id uuid REFERENCES public.students(id) ON DELETE CASCADE,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(seat_layout_id, seat_position),
  UNIQUE(seat_layout_id, student_id) -- One student per layout
);

-- Enable RLS
ALTER TABLE public.seat_layouts ENABLE ROW LEVEL Security;
ALTER TABLE public.seat_assignments ENABLE ROW LEVEL Security;

-- Create policies for seat_layouts
CREATE POLICY "Allow all operations on seat_layouts" 
  ON public.seat_layouts 
  FOR ALL 
  USING (true);

-- Create policies for seat_assignments  
CREATE POLICY "Allow all operations on seat_assignments" 
  ON public.seat_assignments 
  FOR ALL 
  USING (true);

-- Create trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_seat_layouts_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER seat_layouts_updated_at_trigger
    BEFORE UPDATE ON public.seat_layouts
    FOR EACH ROW
    EXECUTE FUNCTION update_seat_layouts_updated_at();

CREATE OR REPLACE FUNCTION update_seat_assignments_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER seat_assignments_updated_at_trigger
    BEFORE UPDATE ON public.seat_assignments
    FOR EACH ROW
    EXECUTE FUNCTION update_seat_assignments_updated_at();
