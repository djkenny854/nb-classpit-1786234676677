
-- First, let's ensure we have proper tables for subjects and teachers that the timetable references
-- Create subjects table if it doesn't exist with proper structure
CREATE TABLE IF NOT EXISTS subjects (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  code text,
  description text,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Create teachers table if it doesn't exist with proper structure  
CREATE TABLE IF NOT EXISTS teachers (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  email text,
  phone text,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Update the timetable table to use proper foreign key references
ALTER TABLE timetable 
DROP CONSTRAINT IF EXISTS timetable_subject_id_fkey,
DROP CONSTRAINT IF EXISTS timetable_teacher_id_fkey;

-- Add foreign key constraints
ALTER TABLE timetable 
ADD CONSTRAINT timetable_subject_id_fkey 
FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE SET NULL,
ADD CONSTRAINT timetable_teacher_id_fkey 
FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE SET NULL;

-- Create an index for better performance on timetable queries
CREATE INDEX IF NOT EXISTS idx_timetable_class_day_period 
ON timetable(class_name, day_of_week, period_number);

-- Ensure we have some sample subjects and teachers for testing
INSERT INTO subjects (name, code) VALUES 
('Mathematics', 'MATH'),
('English', 'ENG'),
('Science', 'SCI'),
('History', 'HIST'),
('Geography', 'GEO'),
('Art', 'ART'),
('Physical Education', 'PE')
ON CONFLICT DO NOTHING;

INSERT INTO teachers (name, email) VALUES 
('Mr. Smith', 'smith@school.edu'),
('Ms. Johnson', 'johnson@school.edu'),
('Dr. Brown', 'brown@school.edu'),
('Mrs. Davis', 'davis@school.edu'),
('Mr. Wilson', 'wilson@school.edu')
ON CONFLICT DO NOTHING;

-- Get all unique classes from students table for timetable management
-- This will help us populate the class dropdown dynamically
CREATE OR REPLACE VIEW available_classes AS
SELECT DISTINCT 
  class as class_name,
  class as class_id,
  COUNT(*) as student_count
FROM students 
WHERE class IS NOT NULL 
GROUP BY class
ORDER BY class;
